<?php
if (!defined('ABSPATH')) {
    exit;
}
$step = isset($_GET['step']) ? (int) $_GET['step'] : 1;
?>
<div class="wrap pcc-wizard-wrap">
    <div class="pcc-wizard-container">
        <!-- Header -->
        <div class="pcc-wizard-header">
            <div class="pcc-wizard-logo">
                <h2>Woo OTEC Moodle <span>Setup</span></h2>
            </div>
            <div class="pcc-wizard-stepper">
                <ul>
                    <li class="<?php echo $step === 1 ? 'active' : ($step > 1 ? 'done' : ''); ?>">1. Conexión</li>
                    <li class="<?php echo $step === 2 ? 'active' : ($step > 2 ? 'done' : ''); ?>">2. Validación</li>
                    <li class="<?php echo $step === 3 ? 'active' : ($step > 3 ? 'done' : ''); ?>">3. Roles</li>
                    <li class="<?php echo $step === 4 ? 'active' : ($step > 4 ? 'done' : ''); ?>">4. Configuración</li>
                    <li class="<?php echo $step === 5 ? 'active' : ''; ?>">5. ¡Listo!</li>
                </ul>
            </div>
        </div>

        <!-- Content -->
        <div class="pcc-wizard-content">
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="pcc_woootec_wizard_save">
                <input type="hidden" name="step" value="<?php echo esc_attr($step); ?>">
                <?php wp_nonce_field('pcc_woootec_wizard_save', 'wizard_nonce'); ?>

                <div class="pcc-wizard-step-body">
                    <?php
                    $step_file = PCC_WOOOTEC_PRO_PATH . 'admin/wizard/views/step-' . $step . '.php';
                    if (file_exists($step_file)) {
                        include $step_file;
                    } else {
                        echo '<p>Paso no encontrado.</p>';
                    }
                    ?>
                </div>

                <div class="pcc-wizard-footer">
                    <?php if ($step > 1 && $step < 5): ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=pcc-woootec-setup&step=' . ($step - 1))); ?>" class="button button-secondary pcc-btn-back">Volver</a>
                    <?php endif; ?>

                    <?php if ($step < 5): ?>
                        <button type="submit" class="button button-primary pcc-btn-next">Continuar</button>
                    <?php else: ?>
                        <button type="submit" class="button button-primary pcc-btn-finish">Finalizar e ir al Panel</button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>
