<?php
if (!defined('ABSPATH')) {
    exit;
}

$price = PCC_WooOTEC_Pro_Core::instance()->get_option('default_price', '0');
$instructor = PCC_WooOTEC_Pro_Core::instance()->get_option('default_instructor', 'No asignado');
?>
<h3>Paso 4: Parámetros del Curso</h3>
<p>Define los parámetros por defecto que usarán los productos (cursos) cuando los sincronices desde Moodle hacia WooCommerce.</p>

<table class="form-table">
    <tr>
        <th><label for="default_price">Precio por Defecto</label></th>
        <td>
            <input type="text" name="default_price" id="default_price" value="<?php echo esc_attr($price); ?>" class="regular-text">
            <p class="description">Por ejemplo, 10000. Puedes dejarlo en 0 para crearlo gratuito o rellenarlo luego producto a producto.</p>
        </td>
    </tr>
    <tr>
        <th><label for="default_instructor">Instructor por Defecto</label></th>
        <td>
            <input type="text" name="default_instructor" id="default_instructor" value="<?php echo esc_attr($instructor); ?>" class="regular-text">
            <p class="description">Si el detector automático no encuentra un profesor en Moodle, se aplicará este nombre.</p>
        </td>
    </tr>
</table>
