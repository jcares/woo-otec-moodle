<?php
if (!defined('ABSPATH')) {
    exit;
}
$moodle_url = PCC_WooOTEC_Pro_Core::instance()->get_option('moodle_url', '');
$moodle_token = PCC_WooOTEC_Pro_Core::instance()->get_option('moodle_token', '');
?>
<h3>Paso 1: Conexión con Moodle</h3>
<p>Ingresa la URL y el Token de tu Moodle para conectar la plataforma. Si no sabes cómo conseguir el Token, revisa la documentación oficial de Moodle.</p>

<table class="form-table">
    <tr>
        <th><label for="moodle_url">URL de Moodle</label></th>
        <td>
            <input type="url" name="moodle_url" id="moodle_url" value="<?php echo esc_attr($moodle_url); ?>" class="regular-text" required placeholder="https://mi-moodle.com">
            <p class="description">La URL raíz donde está instalado Moodle. Asegúrate de incluir https://</p>
        </td>
    </tr>
    <tr>
        <th><label for="moodle_token">Token API Web Services</label></th>
        <td>
            <input type="password" name="moodle_token" id="moodle_token" value="<?php echo esc_attr($moodle_token); ?>" class="regular-text" required>
            <p class="description">El token generado para el usuario web service en Moodle.</p>
        </td>
    </tr>
</table>
