<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<h3>Paso 5: ¡Todo Listo!</h3>
<p>Has terminado la configuración básica para que Woo OTEC Moodle funcione correctamente. Ahora puedes comenzar a sincronizar tus cursos y crear productos.</p>

<div class="pcc-wizard-test-box success">
    <span class="dashicons dashicons-megaphone"></span>
    <h4>Módulo Activo</h4>
    <p>El plugin está configurado y operando de forma activa en WooCommerce. 
       Haz clic en el botón de finalizar para entrar a administrar los cursos, cambiar plantillas de correo y sincronizar Moodle.</p>
</div>
