<?php
if (!defined('ABSPATH')) {
    exit;
}

$role_id = PCC_WooOTEC_Pro_Core::instance()->get_option('student_role_id', 5);
?>
<h3>Paso 3: Roles y Permisos</h3>
<p>En este paso configuramos el ID del rol al cual el alumno será añadido en Moodle al comprar el curso.</p>

<table class="form-table">
    <tr>
        <th><label for="student_role_id">ID de Rol de Estudiante</label></th>
        <td>
            <input type="number" name="student_role_id" id="student_role_id" value="<?php echo esc_attr($role_id); ?>" class="small-text" required min="1">
            <p class="description">Por defecto en Moodle, el rol de estudiante (student) suele tener el <strong>ID 5</strong>. Cámbialo si tu Moodle usa un rol distinto.</p>
        </td>
    </tr>
</table>
