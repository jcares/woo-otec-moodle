<?php
if (!defined('ABSPATH')) {
    exit;
}

$api = PCC_WooOTEC_Pro_API::instance();
$connection_ok = $api->test_connection();
?>
<h3>Paso 2: Validación de Conexión</h3>
<p>Vamos a probar que las credenciales ingresadas en el paso anterior son válidas y tienen los permisos necesarios.</p>

<div class="pcc-wizard-test-box <?php echo $connection_ok ? 'success' : 'error'; ?>">
    <?php if ($connection_ok): ?>
        <span class="dashicons dashicons-yes-alt"></span>
        <h4>¡Conexión Exitosa!</h4>
        <p>Logramos conectar con éxito a tu plataforma Moodle usando el token proporcionado.</p>
    <?php else: ?>
        <span class="dashicons dashicons-warning"></span>
        <h4>Fallo en la Conexión</h4>
        <p>No pudimos conectar con Moodle. Por favor, <strong>vuelve al paso anterior</strong> revisa tus credenciales, URL y que la API REST esté habilitada.</p>
    <?php endif; ?>
</div>

<?php if (!$connection_ok): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var btnNext = document.querySelector('.pcc-btn-next');
            if(btnNext) btnNext.style.display = 'none'; // Impide avanzar si falla
        });
    </script>
<?php endif; ?>
