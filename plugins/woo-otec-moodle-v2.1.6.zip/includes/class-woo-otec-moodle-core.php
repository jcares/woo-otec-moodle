<?php
/**
 * Core del plugin Woo OTEC Moodle.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gestión de tareas programadas (Cron).
 */
final class Woo_OTEC_Moodle_Cron {

	public const HOOK_SYNC = 'woo_otec_moodle_hourly_sync';

	public static function boot(): void {
		add_filter( 'cron_schedules', array( __CLASS__, 'register_schedule' ) );
		add_action( self::HOOK_SYNC, array( __CLASS__, 'run_sync' ) );
		self::ensure_scheduled();
	}

	public static function install(): void {
		self::boot();
	}

	public static function register_schedule( array $schedules ): array {
		if ( ! isset( $schedules['woo_otec_moodle_hourly'] ) ) {
			$schedules['woo_otec_moodle_hourly'] = array(
				'interval' => HOUR_IN_SECONDS,
				'display'  => 'PCC WooOTEC Chile PRO - Cada hora',
			);
		}
		return $schedules;
	}

	public static function ensure_scheduled(): void {
		if ( ! wp_next_scheduled( self::HOOK_SYNC ) ) {
			wp_schedule_event( time() + 300, 'woo_otec_moodle_hourly', self::HOOK_SYNC );
		}
	}

	public static function unschedule(): void {
		$timestamp = wp_next_scheduled( self::HOOK_SYNC );
		while ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::HOOK_SYNC );
			$timestamp = wp_next_scheduled( self::HOOK_SYNC );
		}
	}

	public static function run_sync(): void {
		Woo_OTEC_Moodle_Core::instance()->make( 'sync' )->run( false );
	}
}

/**
 * Gestión del Single Sign-On (SSO) con Moodle.
 */
final class Woo_OTEC_Moodle_SSO {

	/** @var Woo_OTEC_Moodle_SSO|null */
	private static ?Woo_OTEC_Moodle_SSO $instance = null;

	public static function instance(): Woo_OTEC_Moodle_SSO {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
	}

	public function is_enabled(): bool {
		return 'yes' === Woo_OTEC_Moodle_Core::instance()->get_option( 'sso_enabled', 'yes' );
	}

	public function get_base_url(): string {
		$custom = trim( (string) Woo_OTEC_Moodle_Core::instance()->get_option( 'sso_base_url', '' ) );
		if ( '' !== $custom ) {
			return rtrim( $custom, '/' );
		}
		return Woo_OTEC_Moodle_Core::instance()->make( 'api' )->get_moodle_url();
	}

	public function build_url( string $email, int $course_id = 0 ): string {
		if ( ! $this->is_enabled() ) {
			return '';
		}
		$base_url = $this->get_base_url();
		if ( '' === $base_url ) {
			return '';
		}
		$base_url = rtrim( $base_url, '/' );
		if ( str_ends_with( $base_url, '/login' ) || str_ends_with( $base_url, '/login/index.php' ) ) {
			return esc_url_raw( $base_url );
		}
		return esc_url_raw( $base_url . '/login' );
	}

	/**
	 * Almacena las URLs de acceso en el pedido.
	 *
	 * @param mixed   $order      Pedido (WC_Order).
	 * @param WP_User $user       Usuario.
	 * @param array   $course_ids IDs de los cursos.
	 * @return array
	 */
	public function store_order_urls( $order, WP_User $user, array $course_ids ): array {
		if ( ! $order instanceof WC_Order ) {
			return array();
		}

		$urls = array();
		foreach ( $course_ids as $course_id ) {
			$url = $this->build_url( (string) $user->user_email, (int) $course_id );
			if ( '' !== $url ) {
				$urls[ (int) $course_id ] = $url;
			}
		}
		$order->update_meta_data( '_pcc_moodle_access_urls', $urls );
		$order->update_meta_data( '_moodle_access_url', ! empty( $urls ) ? (string) reset( $urls ) : $this->build_url( (string) $user->user_email ) );
		return $urls;
	}
}

/**
 * Clase principal que gestiona la carga y servicios del plugin.
 */
final class Woo_OTEC_Moodle_Core {

	/**
	 * Instancia única de la clase.
	 *
	 * @var Woo_OTEC_Moodle_Core|null
	 */
	private static ?Woo_OTEC_Moodle_Core $instance = null;

	/**
	 * Valores por defecto del plugin.
	 *
	 * @var array
	 */
	private array $defaults = array();

	/**
	 * Registro de servicios.
	 *
	 * @var array<string, callable> Registro de servicios (Tarea #4)
	 */
	private array $services = array();

	/**
	 * Instancias resueltas.
	 *
	 * @var array<string, mixed> Instancias resueltas
	 */
	private array $resolved = array();

	/**
	 * Obtiene la instancia única de la clase.
	 *
	 * @return Woo_OTEC_Moodle_Core
	 */
	public static function instance(): Woo_OTEC_Moodle_Core {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor privado.
	 */
	private function __construct() {
		$defaults = file_exists( WOO_OTEC_MOODLE_PATH . 'config/defaults.php' )
			? require WOO_OTEC_MOODLE_PATH . 'config/defaults.php'
			: array();

		$this->defaults = is_array( $defaults ) ? $defaults : array();
	}

	/**
	 * Obtiene los valores por defecto.
	 *
	 * @return array
	 */
	public function get_defaults(): array {
		return $this->defaults;
	}

	/**
	 * Obtiene una opción del plugin.
	 *
	 * @param string $key      Nombre de la opción.
	 * @param mixed  $fallback Valor por defecto si no existe.
	 * @return mixed
	 */
	public function get_option( string $key, mixed $fallback = null ): mixed {
		$option_name = 'woo_otec_moodle_' . $key;
		$value       = get_option( $option_name, null );
		if ( null === $value ) {
			if ( array_key_exists( $key, $this->defaults ) ) {
				return $this->defaults[ $key ];
			}
			return $fallback;
		}

		return $value;
	}

	/**
	 * Actualiza una opción del plugin.
	 *
	 * @param string $key   Nombre de la opción.
	 * @param mixed  $value Nuevo valor.
	 * @return bool
	 */
	public function update_option( string $key, mixed $value ): bool {
		$option_name = 'woo_otec_moodle_' . $key;
		return update_option( $option_name, $value );
	}

	/**
	 * Inicia el plugin.
	 */
	public function boot(): void {
		$this->load_dependencies();
		$this->register_hooks();

		// Cargar administración inmediatamente si es admin.
		if ( is_admin() ) {
			if ( class_exists( 'Woo_OTEC_Moodle_Admin' ) ) {
				$this->make( 'admin' )->boot();
			}
			if ( class_exists( 'Woo_OTEC_Moodle_Asistente' ) ) {
				$this->make( 'asistente' )->boot();
			}
		}
	}

	/**
	 * Función de activación del plugin.
	 */
	public static function activate(): void {
		$core = self::instance();
		$core->load_dependencies();
		$core->register_default_options();

		if ( class_exists( 'Woo_OTEC_Moodle_Cron' ) ) {
			Woo_OTEC_Moodle_Cron::install();
		}

		if ( class_exists( 'Woo_OTEC_Moodle_Logger' ) ) {
			Woo_OTEC_Moodle_Logger::get_directory();
		}

		flush_rewrite_rules();
	}

	/**
	 * Desactiva el plugin.
	 */
	public static function deactivate(): void {
		if ( class_exists( 'Woo_OTEC_Moodle_Cron' ) ) {
			Woo_OTEC_Moodle_Cron::unschedule();
		}
	}

	/**
	 * Registra las opciones por defecto.
	 */
	public function register_default_options(): void {
		foreach ( $this->defaults as $key => $value ) {
			$option_name = 'woo_otec_moodle_' . $key;
			if ( get_option( $option_name, null ) === null ) {
				add_option( $option_name, $value );
			}
		}
	}

	/**
	 * Carga las dependencias del plugin.
	 */
	private function load_dependencies(): void {

		$files = array(
			'includes/class-woo-otec-moodle-logger.php',
			'includes/class-woo-otec-moodle-api.php',
			'includes/class-woo-otec-moodle-sync.php',
			'includes/class-woo-otec-moodle-enroll.php',
			'public/class-woo-otec-moodle-frontend.php',
			'admin/class-woo-otec-moodle-admin.php',
			'admin/asistente/class-woo-otec-moodle-asistente.php',
		);

		foreach ( $files as $file ) {
			$path = WOO_OTEC_MOODLE_PATH . $file;
			if ( file_exists( $path ) ) {
				require_once $path;
			}
		}

		// Registrar servicios en el contenedor.
		$this->register_services();
	}

	// -------------------------------------------------------------------------
	// Contenedor de servicios (Tarea #4)
	// -------------------------------------------------------------------------

	/**
	 * Registra una fábrica de servicio.
	 *
	 * @param string   $id      Identificador del servicio.
	 * @param callable $factory Función que retorna la instancia.
	 */
	public function register( string $id, callable $factory ): void {
		$this->services[ $id ] = $factory;
		unset( $this->resolved[ $id ] ); // Invalidar caché si se re-registra.
	}

	/**
	 * Resuelve y devuelve un servicio registrado.
	 *
	 * @param string $id Identificador del servicio.
	 * @throws \RuntimeException Si el servicio no está registrado.
	 * @return mixed
	 */
	public function make( string $id ): mixed {
		if ( isset( $this->resolved[ $id ] ) ) {
			return $this->resolved[ $id ];
		}

		if ( ! isset( $this->services[ $id ] ) ) {
			/* translators: %s: service ID */
			throw new \RuntimeException( esc_html( sprintf( 'Servicio \'%s\' no registrado en el contenedor.', $id ) ) );
		}

		$this->resolved[ $id ] = ( $this->services[ $id ] )();
		return $this->resolved[ $id ];
	}

	/**
	 * Registra los servicios principales del plugin.
	 */
	private function register_services(): void {
		if ( class_exists( 'Woo_OTEC_Moodle_API' ) ) {
			$this->register( 'api', fn() => Woo_OTEC_Moodle_API::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Sync' ) ) {
			$this->register( 'sync', fn() => Woo_OTEC_Moodle_Sync::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Mailer' ) ) {
			$this->register( 'mailer', fn() => Woo_OTEC_Moodle_Mailer::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Logger' ) ) {
			$this->register( 'logger', fn() => Woo_OTEC_Moodle_Logger::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Enroll' ) ) {
			$this->register( 'enroll', fn() => Woo_OTEC_Moodle_Enroll::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_SSO' ) ) {
			$this->register( 'sso', fn() => Woo_OTEC_Moodle_SSO::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Mapper' ) ) {
			$this->register( 'mapper', fn() => Woo_OTEC_Moodle_Mapper::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Admin' ) ) {
			$this->register( 'admin', fn() => Woo_OTEC_Moodle_Admin::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Asistente' ) ) {
			$this->register( 'asistente', fn() => Woo_OTEC_Moodle_Asistente::instance() );
		}
	}

	/**
	 * Registra los ganchos principales.
	 */
	private function register_hooks(): void {

		add_action( 'init', array( $this, 'register_runtime' ), 5 );
		add_action( 'before_woocommerce_init', array( $this, 'declare_woocommerce_compatibility' ) );
	}

	/**
	 * Carga el textdomain del plugin.
	 */
	public function load_textdomain(): void {
		load_plugin_textdomain( 'woo-otec-moodle', false, dirname( WOO_OTEC_MOODLE_BASENAME ) . '/languages' );
	}

	/**
	 * Registra el tiempo de ejecución.
	 */
	public function register_runtime(): void {
		$this->load_textdomain();
		$this->register_default_options();

		// FRONTEND.
		if ( ! is_admin() ) {
			if ( class_exists( 'Woo_OTEC_Moodle_Frontend' ) ) {
				Woo_OTEC_Moodle_Frontend::instance()->boot();
			}
		}

		if ( class_exists( 'Woo_OTEC_Moodle_Mailer' ) ) {
			$this->make( 'mailer' );
		}

		if ( class_exists( 'Woo_OTEC_Moodle_Enroll' ) ) {
			$this->make( 'enroll' )->boot();
		}

		if ( class_exists( 'Woo_OTEC_Moodle_Cron' ) ) {
			Woo_OTEC_Moodle_Cron::boot();
		}
	}

	/**
	 * Declara la compatibilidad con WooCommerce.
	 */
	public function declare_woocommerce_compatibility(): void {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'custom_order_tables',
				WOO_OTEC_MOODLE_FILE,
				true
			);
		}
	}
}
