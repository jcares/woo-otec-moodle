<?php
/**
 * API para el plugin Woo OTEC Moodle.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Excepción dedicada para errores de la API de Moodle.
 */
class Woo_OTEC_Moodle_Exception extends RuntimeException {

	/** @var string Código de error. */
	private string $error_code;

	/** @var string Función de Moodle. */
	private string $moodle_function;

	/** @var array Contexto adicional. */
	private array $context;

	/**
	 * Constructor.
	 */
	public function __construct( string $message, string $error_code = '', string $moodle_function = '', array $context = array(), int $code = 0, ?\Throwable $previous = null ) {
		parent::__construct( $message, $code, $previous );
		$this->error_code      = $error_code;
		$this->moodle_function = $moodle_function;
		$this->context         = $context;
	}

	/**
	 * @return string
	 */
	public function get_error_code(): string {
		return $this->error_code;
	}

	/**
	 * @return string
	 */
	public function get_moodle_function(): string {
		return $this->moodle_function;
	}

	/**
	 * @return array
	 */
	public function get_context(): array {
		return $this->context;
	}

	/**
	 * @return \WP_Error
	 */
	public function to_wp_error(): \WP_Error {
		return new \WP_Error( $this->error_code ?: 'pcc_moodle_error', $this->getMessage(), $this->context );
	}
}

/**
 * Clase que gestiona las peticiones a la API de Moodle.
 */
final class Woo_OTEC_Moodle_API {
	/**
	 * Instancia única de la clase.
	 *
	 * @var Woo_OTEC_Moodle_API|null
	 */
	private static ?Woo_OTEC_Moodle_API $instance = null;

	/**
	 * Obtiene la instancia única de la clase.
	 *
	 * @return Woo_OTEC_Moodle_API
	 */
	public static function instance(): Woo_OTEC_Moodle_API {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor privado.
	 */
	private function __construct() {
	}

	/**
	 * Obtiene la URL de Moodle.
	 *
	 * @return string
	 */
	public function get_moodle_url(): string {
		$url = (string) Woo_OTEC_Moodle_Core::instance()->get_option( 'moodle_url', '' );
		return rtrim( trim( $url ), '/' );
	}

	/**
	 * Obtiene el token de la API.
	 *
	 * @return string
	 */
	public function get_token(): string {
		return trim( (string) Woo_OTEC_Moodle_Core::instance()->get_option( 'moodle_token', '' ) );
	}

	/**
	 * Obtiene el ID del rol de estudiante.
	 *
	 * @return int
	 */
	public function get_student_role_id(): int {
		return max( 1, (int) Woo_OTEC_Moodle_Core::instance()->get_option( 'student_role_id', 5 ) );
	}

	// -------------------------------------------------------------------------
	// Núcleo HTTP: lanza PCC_Moodle_Exception internamente
	// -------------------------------------------------------------------------

	/**
	 * Realiza la petición HTTP a Moodle.
	 * Lanza Woo_OTEC_Moodle_Exception ante cualquier error.
	 *
	 * @param string $function_name Nombre de la función de Moodle.
	 * @param array  $params        Parámetros de la función.
	 * @param array  $args          Argumentos adicionales para wp_remote_post.
	 * @throws Woo_OTEC_Moodle_Exception Si hay un error en la configuración o en la petición.
	 * @throws Woo_OTEC_Moodle_Exception Si la respuesta no es válida o hay error de la API.
	 * @return mixed
	 */
	private function request( string $function_name, array $params = array(), array $args = array() ): mixed {
		$moodle_url = $this->get_moodle_url();
		$token      = $this->get_token();

		if ( '' === $moodle_url || '' === $token ) {
			throw new Woo_OTEC_Moodle_Exception(
				esc_html( 'Moodle URL o token no configurado.' ),
				'pcc_missing_config',
				sanitize_key( $function_name )
			);
		}

		$response = wp_remote_post(
			$moodle_url . '/webservice/rest/server.php',
			wp_parse_args(
				$args,
				array(
					'timeout' => 60,
					'body'    => array_merge(
						array(
							'wstoken'            => $token,
							'wsfunction'         => sanitize_key( $function_name ),
							'moodlewsrestformat' => 'json',
						),
						$params
					),
				)
			)
		);

		if ( is_wp_error( $response ) ) {
			$error_msg = (string) $response->get_error_message();

			if ( false !== strpos( $error_msg, 'Could not resolve host' ) ) {
				$friendly = 'Error de Red: No se puede encontrar el servidor de Moodle (DNS). Revisa que la URL sea correcta.';
			} elseif ( false !== strpos( $error_msg, 'Timeout was reached' ) || false !== strpos( $error_msg, 'timed out' ) ) {
				$friendly = 'Error de Tiempo de Espera: El servidor de Moodle tardó demasiado en responder.';
			} else {
				$friendly = $error_msg;
			}

			Woo_OTEC_Moodle_Logger::error(
				'Error HTTP Moodle',
				array(
					'function' => $function_name,
					'error'    => $error_msg,
				)
			);

			throw new Woo_OTEC_Moodle_Exception( esc_html( $friendly ), 'pcc_http_error', sanitize_key( $function_name ), array( 'original' => esc_html( $error_msg ) ) );
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		$body        = (string) wp_remote_retrieve_body( $response );

		if ( $status_code < 200 || $status_code >= 300 ) {
			Woo_OTEC_Moodle_Logger::error(
				'Respuesta HTTP inválida Moodle',
				array(
					'function' => $function_name,
					'status'   => $status_code,
				)
			);
			/* translators: %d: HTTP status code */
			throw new Woo_OTEC_Moodle_Exception(
				esc_html( sprintf( 'Respuesta HTTP inválida desde Moodle (código %d).', $status_code ) ),
				'pcc_http_error',
				sanitize_key( $function_name ),
				array( 'status_code' => absint( $status_code ) )
			);
		}

		$decoded = json_decode( $body );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			Woo_OTEC_Moodle_Logger::error(
				'JSON inválido desde Moodle',
				array(
					'function' => $function_name,
					'body'     => substr( $body, 0, 500 ),
				)
			);
			throw new Woo_OTEC_Moodle_Exception( esc_html( 'JSON inválido desde Moodle.' ), 'pcc_invalid_json', sanitize_key( $function_name ) );
		}

		if ( is_object( $decoded ) && ( isset( $decoded->exception ) || isset( $decoded->errorcode ) ) ) {
			$msg = isset( $decoded->message ) ? (string) $decoded->message : 'Error Moodle API';
			Woo_OTEC_Moodle_Logger::error(
				'Excepción Moodle',
				array(
					'function'  => $function_name,
					'exception' => isset( $decoded->exception ) ? (string) $decoded->exception : '',
					'errorcode' => isset( $decoded->errorcode ) ? (string) $decoded->errorcode : '',
					'message'   => $msg,
				)
			);

			throw new Woo_OTEC_Moodle_Exception(
				esc_html( $msg ),
				'pcc_moodle_exception',
				sanitize_key( $function_name ),
				array( 'errorcode' => isset( $decoded->errorcode ) ? esc_html( (string) $decoded->errorcode ) : '' )
			);
		}

		return $decoded;
	}

	/**
	 * Wrapper público: captura Woo_OTEC_Moodle_Exception y devuelve WP_Error.
	 *
	 * @param string $function_name Nombre de la función.
	 * @param array  $params        Parámetros.
	 * @param array  $args          Argumentos adicionales.
	 * @return mixed
	 */
	public function safe_request( string $function_name, array $params = array(), array $args = array() ): mixed {
		try {
			return $this->request( $function_name, $params, $args );
		} catch ( Woo_OTEC_Moodle_Exception $e ) {
			return $e->to_wp_error();
		}
	}

	// -------------------------------------------------------------------------
	// Métodos públicos de la API
	// -------------------------------------------------------------------------

	/**
	 * Prueba la conexión con Moodle.
	 *
	 * @return bool
	 */
	public function test_connection(): bool {
		try {
			$this->request( 'core_webservice_get_site_info' );
			return true;
		} catch ( Woo_OTEC_Moodle_Exception $e ) {
			return false;
		}
	}

	/**
	 * Obtiene las categorías de Moodle.
	 *
	 * @return array|WP_Error
	 */
	public function get_categories(): array|WP_Error {
		$response = $this->safe_request( 'core_course_get_categories' );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		return is_array( $response ) ? $response : array();
	}

	/**
	 * Obtiene todos los cursos de Moodle.
	 *
	 * @return array|WP_Error
	 */
	public function get_courses(): array|WP_Error {
		$response = $this->safe_request( 'core_course_get_courses' );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		return is_array( $response ) ? $response : array();
	}

	/**
	 * Obtiene los cursos de una categoría.
	 *
	 * @param int $category_id ID de la categoría.
	 * @return array|WP_Error
	 */
	public function get_courses_by_category( int $category_id ): array|WP_Error {
		$response = $this->safe_request(
			'core_course_get_courses_by_field',
			array(
				'field' => 'category',
				'value' => (string) $category_id,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return is_object( $response ) && isset( $response->courses ) ? (array) $response->courses : array();
	}

	/**
	 * Obtiene los profesores de un curso.
	 *
	 * @param int $course_id ID del curso.
	 * @return array
	 */
	public function get_course_teachers( int $course_id ): array {
		try {
			$params   = array( 'courseids' => array( $course_id ) );
			$response = $this->request( 'core_enrol_get_enrolled_users', $params );

			if ( ! is_array( $response ) ) {
				return array();
			}

			$teachers = array();
			foreach ( $response as $user ) {
				$is_teacher = false;
				if ( isset( $user->roles ) && is_array( $user->roles ) ) {
					foreach ( $user->roles as $role ) {
						$shortname = isset( $role->shortname ) ? (string) $role->shortname : '';
						if ( in_array( $shortname, array( 'editingteacher', 'teacher' ), true ) ) {
							$is_teacher = true;
							break;
						}
					}
				}

				if ( $is_teacher ) {
					$teachers[] = isset( $user->fullname ) ? (string) $user->fullname : ( ( $user->firstname ?? '' ) . ' ' . ( $user->lastname ?? '' ) );
				}
			}

			return $teachers;
		} catch ( Woo_OTEC_Moodle_Exception $e ) {
			return array();
		}
	}

	/**
	 * Busca un usuario por email.
	 *
	 * @param string $email Email del usuario.
	 * @return object|null
	 */
	public function find_user_by_email( string $email ): ?object {
		try {
			$params = array(
				'field'  => 'email',
				'values' => array( $email ),
			);

			$response = $this->request( 'core_user_get_users_by_field', $params );

			if ( is_array( $response ) && ! empty( $response ) ) {
				return (object) $response[0];
			}

			return null;
		} catch ( Woo_OTEC_Moodle_Exception $e ) {
			return null;
		}
	}

	/**
	 * Crea un nuevo usuario en Moodle.
	 *
	 * @param mixed $user Datos del usuario (array o WP_User).
	 * @return array|WP_Error
	 */
	public function create_user( $user ): array|WP_Error {
		$payload = $this->normalize_user_payload( $user );
		if ( ! $payload ) {
			return new WP_Error( 'pcc_invalid_user_payload', 'Datos insuficientes para crear usuario Moodle.' );
		}

		$password = wp_generate_password( 14, true, true );

		try {
			$response = $this->request(
				'core_user_create_users',
				array(
					'users' => array(
						array(
							'username'  => (string) $payload['email'],
							'password'  => $password,
							'firstname' => (string) $payload['firstname'],
							'lastname'  => (string) $payload['lastname'],
							'email'     => (string) $payload['email'],
						),
					),
				)
			);
		} catch ( Woo_OTEC_Moodle_Exception $e ) {
			return $e->to_wp_error();
		}

		if ( ! is_array( $response ) || empty( $response[0]->id ) ) {
			return new WP_Error( 'pcc_moodle_user_create_failed', 'No fue posible crear el usuario en Moodle.' );
		}

		return array(
			'id'       => (int) $response[0]->id,
			'password' => $password,
		);
	}

	/**
	 * Obtiene un usuario por email o lo crea si no existe.
	 *
	 * @param array $data Datos del usuario.
	 * @return array|WP_Error
	 */
	public function get_or_create_user( array $data ): array|WP_Error {
		$email = sanitize_email( $data['email'] ?? '' );
		if ( '' === $email ) {
			return new WP_Error( 'pcc_invalid_email', 'Email inválido.' );
		}

		// 1. Buscar por email.
		$existing = $this->safe_request(
			'core_user_get_users_by_field',
			array(
				'field'  => 'email',
				'values' => array( $email ),
			)
		);

		if ( ! is_wp_error( $existing ) && ! empty( $existing ) && is_array( $existing ) ) {
			$user = is_object( $existing[0] ) ? $existing[0] : (object) $existing[0];
			return array(
				'id'      => (int) $user->id,
				'created' => false,
			);
		}

		// 2. Crear si no existe.
		$password  = wp_generate_password( 12, true, true );
		$password .= 'Aa1!';

		$new_user = array(
			'username'  => strtolower( preg_replace( '/[^a-z0-9]/', '', (string) strstr( $email, '@', true ) ) . wp_rand( 10, 99 ) ),
			'password'  => $password,
			'firstname' => $data['firstname'] ? $data['firstname'] : 'Alumno',
			'lastname'  => $data['lastname'] ? $data['lastname'] : 'Nuevo',
			'email'     => $email,
			'auth'      => 'manual',
		);

		try {
			$created = $this->request( 'core_user_create_users', array( 'users' => array( $new_user ) ) );
		} catch ( Woo_OTEC_Moodle_Exception $e ) {
			return $e->to_wp_error();
		}

		if ( ! empty( $created ) && is_array( $created ) ) {
			$user = is_object( $created[0] ) ? $created[0] : (object) $created[0];
			return array(
				'id'       => (int) $user->id,
				'password' => $password,
				'created'  => true,
			);
		}

		return new WP_Error( 'pcc_create_failed', 'No se pudo crear el usuario en Moodle.' );
	}

	/**
	 * Inscribe a un usuario en un curso de Moodle.
	 *
	 * @param int $moodle_user_id ID del usuario en Moodle.
	 * @param int $course_id      ID del curso en Moodle.
	 * @return bool
	 */
	public function enroll_user( int $moodle_user_id, int $course_id ): bool {
		try {
			$this->request(
				'enrol_manual_enrol_users',
				array(
					'enrolments' => array(
						array(
							'roleid'   => $this->get_student_role_id(),
							'userid'   => $moodle_user_id,
							'courseid' => $course_id,
						),
					),
				)
			);
			return true;
		} catch ( Woo_OTEC_Moodle_Exception $e ) {
			return false;
		}
	}

	/**
	 * Normaliza los datos de un usuario para Moodle.
	 *
	 * @param mixed $user Datos del usuario (array o WP_User).
	 * @return array|false
	 */
	private function normalize_user_payload( $user ): array|false {
		$email     = '';
		$firstname = '';
		$lastname  = '';

		if ( $user instanceof WP_User ) {
			$email     = sanitize_email( (string) $user->user_email );
			$firstname = (string) $user->first_name;
			$lastname  = (string) $user->last_name;

			if ( '' === $firstname ) {
				$parts     = explode( ' ', (string) $user->display_name );
				$firstname = (string) array_shift( $parts );
				$lastname  = ! empty( $parts ) ? implode( ' ', $parts ) : 'Alumno';
			}
		} elseif ( is_array( $user ) ) {
			$email     = sanitize_email( (string) ( $user['email'] ?? '' ) );
			$firstname = sanitize_text_field( (string) ( $user['firstname'] ?? '' ) );
			$lastname  = sanitize_text_field( (string) ( $user['lastname'] ?? '' ) );
		}

		if ( '' === $email ) {
			return false;
		}

		return array(
			'email'     => $email,
			'firstname' => '' !== $firstname ? $firstname : 'Alumno',
			'lastname'  => '' !== $lastname ? $lastname : 'Nuevo',
		);
	}
}
