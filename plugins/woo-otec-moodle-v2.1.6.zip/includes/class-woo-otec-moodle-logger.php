<?php
/**
 * Clase que gestiona el registro de logs del plugin.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Clase que gestiona el registro de logs del plugin.
 */
final class Woo_OTEC_Moodle_Logger {

	/**
	 * Instancia única de la clase.
	 *
	 * @var Woo_OTEC_Moodle_Logger|null
	 */
	private static ?Woo_OTEC_Moodle_Logger $instance = null;

	/**
	 * Obtiene la instancia única de la clase.
	 *
	 * @return Woo_OTEC_Moodle_Logger
	 */
	public static function instance(): Woo_OTEC_Moodle_Logger {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor privado.
	 */
	private function __construct() {
	}

	/**
	 * Nombre del archivo de log de sincronización.
	 */
	public const SYNC_LOG = 'sync.log';

	/**
	 * Nombre del archivo de log de errores.
	 */
	public const ERROR_LOG = 'error.log';

	/**
	 * Nombre del archivo de log principal.
	 */
	public const MAIN_LOG = 'log.txt';

	/**
	 * Registra un mensaje en el log principal.
	 *
	 * @param string $message  Mensaje a registrar.
	 * @param string $filename Nombre del archivo de log.
	 */
	public static function log( string $message, string $filename = self::MAIN_LOG ): void {
		self::write( $filename, 'INFO', $message );
	}

	/**
	 * Registra un mensaje informativo.
	 *
	 * @param string $message Mensaje a registrar.
	 * @param array  $context Contexto adicional.
	 */
	public static function info( string $message, array $context = array() ): void {
		self::write( self::SYNC_LOG, 'INFO', $message, $context );
	}

	/**
	 * Registra un mensaje de error.
	 *
	 * @param string $message Mensaje a registrar.
	 * @param array  $context Contexto adicional.
	 */
	public static function error( string $message, array $context = array() ): void {
		self::write( self::ERROR_LOG, 'ERROR', $message, $context );
	}

	/**
	 * Obtiene el directorio de logs.
	 *
	 * @return string
	 */
	public static function get_directory(): string {
		$directory = WOO_OTEC_MOODLE_PATH . 'logs/';
		self::ensure_directory( $directory );
		return $directory;
	}

	/**
	 * Asegura que el directorio de logs exista y sea seguro.
	 *
	 * @param string $path Ruta del directorio.
	 */
	private static function ensure_directory( string $path ): void {
		if ( ! file_exists( $path ) ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_mkdir
			@mkdir( $path, 0755, true );
			// Añadir index.php por seguridad.
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			file_put_contents( $path . 'index.php', '<?php // Silence is golden' );
			// Añadir .htaccess para prevenir acceso directo.
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			file_put_contents( $path . '.htaccess', 'deny from all' );
		}
	}

	/**
	 * Obtiene la ruta completa de un archivo de log.
	 *
	 * @param string $filename Nombre del archivo.
	 * @return string
	 */
	public static function get_file_path( string $filename ): string {
		return self::get_directory() . ltrim( $filename, '/' );
	}

	/**
	 * Lee el contenido completo de un log.
	 *
	 * @param string $filename Nombre del archivo.
	 * @return string
	 */
	public static function read_full( string $filename ): string {
		$file = self::get_file_path( $filename );
		if ( ! file_exists( $file ) ) {
			return '';
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		return (string) file_get_contents( $file );
	}

	/**
	 * Lee las últimas líneas de un log.
	 *
	 * @param string $filename  Nombre del archivo.
	 * @param int    $max_lines Número máximo de líneas.
	 * @return array
	 */
	public static function read_tail( string $filename, int $max_lines = 200 ): array {
		$file = self::get_file_path( $filename );

		if ( ! file_exists( $file ) ) {
			return array();
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$contents = file_get_contents( $file );
		if ( false === $contents || '' === $contents ) {
			return array();
		}

		$lines = preg_split( '/\r\n|\r|\n/', (string) $contents );
		if ( ! is_array( $lines ) ) {
			return array();
		}

		$lines = array_values( array_filter( $lines, static fn( $line ) => '' !== trim( $line ) ) );
		return array_slice( $lines, -1 * $max_lines );
	}

	/**
	 * Escribe una línea en el log.
	 *
	 * @param string $filename Nombre del archivo.
	 * @param string $level    Nivel de log.
	 * @param string $message  Mensaje.
	 * @param array  $context  Contexto.
	 */
	private static function write( string $filename, string $level, string $message, array $context = array() ): void {
		$line = sprintf(
			'[%s] [%s] %s',
			gmdate( 'c' ),
			$level,
			$message
		);

		if ( ! empty( $context ) ) {
			$line .= ' | ' . wp_json_encode( self::sanitize_context( $context ), JSON_UNESCAPED_UNICODE );
		}

		$line .= PHP_EOL;
		$file  = self::get_file_path( $filename );

		// Native PHP append is much more reliable across disparate hosting environments.
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		file_put_contents( $file, $line, FILE_APPEND | LOCK_EX );
	}

	/**
	 * Sanitiza el contexto eliminando datos sensibles.
	 *
	 * @param array $context Contexto adicional.
	 * @return array
	 */
	private static function sanitize_context( array $context ): array {
		foreach ( array( 'token', 'wstoken', 'moodle_token' ) as $secret_key ) {
			if ( isset( $context[ $secret_key ] ) ) {
				$context[ $secret_key ] = '***';
			}
		}

		return $context;
	}
}
