<?php
/**
 * @var Woo_OTEC_Moodle_Core $core
 * @var array $last_sync
 * @var bool $connection_ok
 * @var array $sync_log
 * @var array $error_log
 * @var string $active_tab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$brand_logo_url        = WOO_OTEC_MOODLE_URL . 'assets/images/logo-pccurico.png';
$last_sync_label       = ! empty( $last_sync['timestamp'] ) ? (string) $last_sync['timestamp'] : 'Sin ejecuciones';
$sync_status           = ! empty( $last_sync['status'] ) ? (string) $last_sync['status'] : 'idle';
$email_from_address    = (string) $core->get_option( 'email_from_address', '' );
$fallback_from_address = Woo_OTEC_Moodle_Core::instance()->make( 'mailer' )->filter_mail_from( get_option( 'admin_email', '' ) );

// Determinar pestaña activa para el renderizado inicial de clases
$requested_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'general';
?>
<div class="wrap pcc-admin-wrap">
	<header class="pcc-brand-bar">
		<div class="pcc-brand-bar__main">
			<img src="<?php echo esc_url( $brand_logo_url ); ?>" alt="PCCurico" class="pcc-brand-bar__logo">
			<h1>PCC WooOTEC Chile PRO <small style="font-size: 12px; opacity: 0.7; font-weight: normal;">v<?php echo esc_html( WOO_OTEC_MOODLE_VERSION ); ?></small></h1>
		</div>
		<div class="pcc-brand-bar__meta">
			<span>Moodle API: <strong><?php echo $connection_ok ? '<span style="color:#2ed8b6;">Conectado</span>' : '<span style="color:#ff5370;">Desconectado</span>'; ?></strong></span>
			<p>Sincronización: <strong><?php echo esc_html( $last_sync_label ); ?></strong></p>
		</div>
	</header>

	<div class="pcc-overview-grid">
		<div class="pcc-overview-card" style="border-left-color: #4099ff;">
			<span class="pcc-overview-card__label">Cursos Sincronizados</span>
			<span class="pcc-overview-card__value"><?php echo (int) ( $last_sync['courses'] ?? 0 ); ?></span>
		</div>
		<div class="pcc-overview-card" style="border-left-color: #2ed8b6;">
			<span class="pcc-overview-card__label">Inscripciones (24h)</span>
			<span class="pcc-overview-card__value"><?php echo (int) ( $last_sync['enrollments'] ?? 0 ); ?></span>
		</div>
		<div class="pcc-overview-card" style="border-left-color: #ffb64d;">
			<span class="pcc-overview-card__label">Estado General</span>
			<span class="pcc-overview-card__value"><?php echo $connection_ok ? 'Operativo' : 'Error API'; ?></span>
		</div>
	</div>

	<div class="pcc-dashboard-layout">
		<aside class="pcc-dashboard-sidebar">
			<div class="pcc-tabs" role="tablist">
				<button type="button" class="pcc-tab <?php echo $requested_tab === 'general' ? 'is-active' : ''; ?>" data-tab="general" role="tab" aria-selected="<?php echo $requested_tab === 'general' ? 'true' : 'false'; ?>">Conectar Moodle</button>
				<button type="button" class="pcc-tab <?php echo $requested_tab === 'sync' ? 'is-active' : ''; ?>" data-tab="sync" role="tab" aria-selected="<?php echo $requested_tab === 'sync' ? 'true' : 'false'; ?>">Sincronización</button>
				<button type="button" class="pcc-tab <?php echo $requested_tab === 'sso' ? 'is-active' : ''; ?>" data-tab="sso" role="tab" aria-selected="<?php echo $requested_tab === 'sso' ? 'true' : 'false'; ?>">Acceso Alumnos</button>
				<button type="button" class="pcc-tab <?php echo $requested_tab === 'templates' ? 'is-active' : ''; ?>" data-tab="templates" role="tab" aria-selected="<?php echo $requested_tab === 'templates' ? 'true' : 'false'; ?>">Metadatos</button>
				<button type="button" class="pcc-tab <?php echo $requested_tab === 'appearance' ? 'is-active' : ''; ?>" data-tab="appearance" role="tab" aria-selected="<?php echo $requested_tab === 'appearance' ? 'true' : 'false'; ?>">Apariencia</button>
				<button type="button" class="pcc-tab <?php echo $requested_tab === 'emails' ? 'is-active' : ''; ?>" data-tab="emails" role="tab" aria-selected="<?php echo $requested_tab === 'emails' ? 'true' : 'false'; ?>">Emails</button>
				<button type="button" class="pcc-tab <?php echo $requested_tab === 'logs' ? 'is-active' : ''; ?>" data-tab="logs" role="tab" aria-selected="<?php echo $requested_tab === 'logs' ? 'true' : 'false'; ?>">Logs</button>
			</div>

			<div style="margin-top: 20px;">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=woo-otec-asistente' ) ); ?>" class="button button-primary button-large" style="width: 100%; text-align: center; padding: 10px;">💫 Iniciar Asistente</a>
			</div>
		</aside>

		<main class="pcc-dashboard-main">
			<form method="post" action="options.php" id="pcc-settings-form">
				<?php settings_fields( 'woo_otec_moodle_settings' ); ?>
				
				<div class="pcc-card">
					<!-- General Tab -->
					<section class="pcc-tab-panel <?php echo $requested_tab === 'general' ? 'is-active' : ''; ?>" id="pcc-panel-general" data-panel="general" role="tabpanel" <?php echo $requested_tab !== 'general' ? 'hidden' : ''; ?>>
						<h3>Configuración de Conexión</h3>
						<p class="description">Establece el puente de comunicación con tu plataforma Moodle.</p>
						<table class="form-table">
							<tr>
								<th scope="row"><label for="woo_otec_moodle_moodle_url">URL del Moodle</label></th>
								<td>
									<input class="regular-text" type="url" id="woo_otec_moodle_moodle_url" name="woo_otec_moodle_moodle_url" value="<?php echo esc_attr( (string) $core->get_option( 'moodle_url', '' ) ); ?>" placeholder="https://tu-moodle.com">
									<p class="pcc-field-help">Debe incluir http:// o https://</p>
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="woo_otec_moodle_moodle_token">Token de Web Service</label></th>
								<td>
									<input class="regular-text" type="password" id="woo_otec_moodle_moodle_token" name="woo_otec_moodle_moodle_token" value="<?php echo esc_attr( (string) $core->get_option( 'moodle_token', '' ) ); ?>" autocomplete="off">
									<p class="pcc-field-help">Generado en Moodle > Administración del sitio > Plugins > Web services.</p>
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="woo_otec_moodle_student_role_id">Role ID de Estudiante</label></th>
								<td>
									<input class="small-text" type="number" id="woo_otec_moodle_student_role_id" name="woo_otec_moodle_student_role_id" value="<?php echo esc_attr( (string) $core->get_option( 'student_role_id', 5 ) ); ?>">
									<p class="pcc-field-help">Por defecto es 5 (estudiante).</p>
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="woo_otec_moodle_default_price">Precio por Defecto</label></th>
								<td>
									<input class="regular-text" type="text" id="woo_otec_moodle_default_price" name="woo_otec_moodle_default_price" value="<?php echo esc_attr( (string) $core->get_option( 'default_price', '49000' ) ); ?>">
									<p class="pcc-field-help">Precio asignado a cursos nuevos si no se especifica otro.</p>
								</td>
							</tr>
						</table>
					</section>

					<!-- Sync Tab -->
					<section class="pcc-tab-panel <?php echo $requested_tab === 'sync' ? 'is-active' : ''; ?>" id="pcc-panel-sync" data-panel="sync" role="tabpanel" <?php echo $requested_tab !== 'sync' ? 'hidden' : ''; ?>>
						<h3>Sincronización de Datos</h3>
						<div class="pcc-sync-result-box">
							<div class="pcc-sync-result-header">
								<strong>Última sincronización</strong>
								<span class="pcc-badge <?php echo $sync_status === 'success' ? 'is-success' : ( $sync_status === 'error' ? 'is-danger' : '' ); ?>">
									<?php echo esc_html( strtoupper( $sync_status ) ); ?>
								</span>
							</div>
							<div class="pcc-sync-result-grid">
								<div class="pcc-sync-result-item">
									<span>Fecha</span>
									<strong><?php echo esc_html( $last_sync_label ); ?></strong>
								</div>
								<div class="pcc-sync-result-item success">
									<span>Cursos</span>
									<strong><?php echo (int) ( $last_sync['courses'] ?? 0 ); ?></strong>
								</div>
								<div class="pcc-sync-result-item warning">
									<span>Errores</span>
									<strong><?php echo (int) ( $last_sync['errors'] ?? 0 ); ?></strong>
								</div>
							</div>
						</div>

						<div class="pcc-settings-actions">
							<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=woo_otec_moodle_run_sync' ), 'woo_otec_moodle_run_sync' ) ); ?>" class="button button-secondary">Sincronizar todo ahora</a>
							<p class="description">Esto buscará todos los cursos en Moodle y actualizará sus datos en WooCommerce.</p>
						</div>
					</section>

					<!-- SSO Tab -->
					<section class="pcc-tab-panel <?php echo $requested_tab === 'sso' ? 'is-active' : ''; ?>" id="pcc-panel-sso" data-panel="sso" role="tabpanel" <?php echo $requested_tab !== 'sso' ? 'hidden' : ''; ?>>
						<h3>Acceso Directo (SSO)</h3>
						<table class="form-table">
							<tr>
								<th scope="row">Activar Auto-Login</th>
								<td>
									<label class="pcc-switch">
										<input type="checkbox" name="woo_otec_moodle_sso_enabled" value="yes" <?php checked( $core->get_option( 'sso_enabled', 'yes' ), 'yes' ); ?>>
										<span class="pcc-slider"></span>
									</label>
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="woo_otec_moodle_sso_base_url">URL de Auto-Login</label></th>
								<td>
									<input class="regular-text" type="url" id="woo_otec_moodle_sso_base_url" name="woo_otec_moodle_sso_base_url" value="<?php echo esc_attr( (string) $core->get_option( 'sso_base_url', '' ) ); ?>">
									<button type="button" id="pcc-test-sso-connection" class="button button-small">Probar conexión</button>
									<span id="sso-test-result" style="margin-left: 10px; font-weight: 600;"></span>
									<p class="pcc-field-help">URL del endpoint de auto-login en Moodle.</p>
								</td>
							</tr>
						</table>
					</section>

					<!-- Templates Tab -->
					<section class="pcc-tab-panel <?php echo $requested_tab === 'templates' ? 'is-active' : ''; ?>" id="pcc-panel-templates" data-panel="templates" role="tabpanel" <?php echo $requested_tab !== 'templates' ? 'hidden' : ''; ?>>
						<h3>Configuración de Metadatos</h3>
						<table class="form-table">
							<tr>
								<th scope="row"><label for="woo_otec_moodle_template_style">Estilo de Ficha de Curso</label></th>
								<td>
									<select id="woo_otec_moodle_template_style" name="woo_otec_moodle_template_style">
										<?php $current_style = $core->get_option( 'template_style', 'classic' ); ?>
										<option value="classic" <?php selected( $current_style, 'classic' ); ?>>Classic (WooCommerce Default)</option>
										<option value="academy" <?php selected( $current_style, 'academy' ); ?>>Academy (Moderna/LMS)</option>
										<option value="pccurico" <?php selected( $current_style, 'pccurico' ); ?>>PCCurico Custom</option>
									</select>
								</td>
							</tr>
							<tr>
								<th scope="row">Mapeo de Campos</th>
								<td>
									<div class="pcc-info-box">
										<p>Selecciona un curso de referencia para ver cómo se mapean los datos de Moodle.</p>
										<select id="woo_otec_moodle_template_reference">
											<option value="">-- Seleccionar curso --</option>
											<?php
											$courses_query = new WP_Query( array(
												'post_type'      => 'product',
												'posts_per_page' => 20,
												'meta_query'     => array(
													array(
														'key'     => '_moodle_id',
														'compare' => 'EXISTS',
													),
												),
											) );
											if ( $courses_query->have_posts() ) {
												while ( $courses_query->have_posts() ) {
													$courses_query->the_post();
													echo '<option value="' . esc_attr( get_the_ID() ) . '">' . esc_html( get_the_title() ) . '</option>';
												}
												wp_reset_postdata();
											}
											?>
										</select>
									</div>
									<div id="pcc-template-fields-container" data-template-fields>
										<!-- Cargado vía AJAX -->
									</div>
								</td>
							</tr>
						</table>
					</section>

					<!-- Appearance Tab -->
					<section class="pcc-tab-panel <?php echo $requested_tab === 'appearance' ? 'is-active' : ''; ?>" id="pcc-panel-appearance" data-panel="appearance" role="tabpanel" <?php echo $requested_tab !== 'appearance' ? 'hidden' : ''; ?>>
						<h3>Apariencia y Colores</h3>
						<p class="description">Personaliza los colores globales de los elementos del plugin.</p>
						<table class="form-table">
							<tr>
								<th scope="row"><label for="woo_otec_moodle_pcc_color_primary">Color Primario</label></th>
								<td>
									<input type="color" id="woo_otec_moodle_pcc_color_primary" name="woo_otec_moodle_pcc_color_primary" value="<?php echo esc_attr( (string) $core->get_option( 'pcc_color_primary', '#023E25' ) ); ?>">
									<p class="pcc-field-help">Usado en botones y marcas principales.</p>
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="woo_otec_moodle_pcc_color_secondary">Color Secundario</label></th>
								<td>
									<input type="color" id="woo_otec_moodle_pcc_color_secondary" name="woo_otec_moodle_pcc_color_secondary" value="<?php echo esc_attr( (string) $core->get_option( 'pcc_color_secondary', '#6EC1E4' ) ); ?>">
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="woo_otec_moodle_pcc_color_text">Color de Texto</label></th>
								<td>
									<input type="color" id="woo_otec_moodle_pcc_color_text" name="woo_otec_moodle_pcc_color_text" value="<?php echo esc_attr( (string) $core->get_option( 'pcc_color_text', '#7A7A7A' ) ); ?>">
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="woo_otec_moodle_pcc_color_accent">Color de Acento</label></th>
								<td>
									<input type="color" id="woo_otec_moodle_pcc_color_accent" name="woo_otec_moodle_pcc_color_accent" value="<?php echo esc_attr( (string) $core->get_option( 'pcc_color_accent', '#61CE70' ) ); ?>">
								</td>
							</tr>
						</table>
					</section>

					<!-- Emails Tab -->
					<section class="pcc-tab-panel <?php echo $requested_tab === 'emails' ? 'is-active' : ''; ?>" id="pcc-panel-emails" data-panel="emails" role="tabpanel" <?php echo $requested_tab !== 'emails' ? 'hidden' : ''; ?>>
						<h3>Notificaciones por Email</h3>
						<table class="form-table">
							<tr>
								<th scope="row">Enviar Email de Acceso</th>
								<td>
									<label class="pcc-switch">
										<input type="checkbox" name="woo_otec_moodle_email_enabled" value="yes" <?php checked( $core->get_option( 'email_enabled', 'yes' ), 'yes' ); ?>>
										<span class="pcc-slider"></span>
									</label>
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="woo_otec_moodle_email_from_address">Email Remitente</label></th>
								<td>
									<input class="regular-text" type="email" id="woo_otec_moodle_email_from_address" name="woo_otec_moodle_email_from_address" value="<?php echo esc_attr( $email_from_address ); ?>" placeholder="<?php echo esc_attr( $fallback_from_address ); ?>">
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="woo_otec_moodle_email_from_name">Nombre Remitente</label></th>
								<td>
									<input class="regular-text" type="text" id="woo_otec_moodle_email_from_name" name="woo_otec_moodle_email_from_name" value="<?php echo esc_attr( (string) $core->get_option( 'email_from_name', '' ) ); ?>" placeholder="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="woo_otec_moodle_email_subject">Asunto del Email</label></th>
								<td>
									<input class="regular-text" type="text" id="woo_otec_moodle_email_subject" name="woo_otec_moodle_email_subject" value="<?php echo esc_attr( (string) $core->get_option( 'email_subject', '' ) ); ?>">
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="woo_otec_moodle_email_template">Plantilla del Mensaje</label></th>
								<td>
									<div class="pcc-email-editor-wrap">
										<textarea class="large-text code" rows="12" id="woo_otec_moodle_email_template" name="woo_otec_moodle_email_template"><?php echo esc_textarea( (string) $core->get_option( 'email_template', '' ) ); ?></textarea>
										<div class="pcc-email-tags" style="margin-top: 10px;">
											<span class="pcc-tag" title="Nombre del alumno">{{nombre}}</span>
											<span class="pcc-tag" title="Email del alumno">{{email}}</span>
											<span class="pcc-tag" title="Password (solo si es nuevo)">{{password}}</span>
											<span class="pcc-tag" title="Nombres de los cursos">{{cursos}}</span>
											<span class="pcc-tag" title="URL de acceso">{{url_acceso}}</span>
											<span class="pcc-tag" title="Nombre del sitio">{{sitio}}</span>
										</div>
									</div>
								</td>
							</tr>
						</table>

						<div class="pcc-email-tools" style="margin-top: 20px; border-top: 1px solid #eee; padding-top: 20px;">
							<button type="button" class="button" data-email-preview>Vista Previa</button>
							<input type="email" id="woo_otec_moodle_email_test_recipient" placeholder="Email para prueba" class="regular-text" style="width: 200px;">
							<button type="button" class="button" data-email-send-test>Enviar Prueba</button>
							<div data-email-feedback style="margin-top: 10px;"></div>
							<div data-email-preview-box style="margin-top: 20px; background: #fff; border: 1px solid #ddd; padding: 20px; border-radius: 4px;"></div>
						</div>
					</section>

					<!-- Logs Tab -->
					<section class="pcc-tab-panel <?php echo $requested_tab === 'logs' ? 'is-active' : ''; ?>" id="pcc-panel-logs" data-panel="logs" role="tabpanel" <?php echo $requested_tab !== 'logs' ? 'hidden' : ''; ?>>
						<h3>Registro de Eventos</h3>
						<div class="pcc-log-viewer-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
							<strong>Últimas 100 líneas del log:</strong>
							<a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=woo_otec_moodle_export_logs&nonce=' . wp_create_nonce( 'woo_otec_moodle_export_logs' ) ) ); ?>" class="button button-secondary">Exportar log completo</a>
						</div>
						<div class="pcc-log-viewer">
							<?php
							if ( ! empty( $error_log ) ) {
								foreach ( $error_log as $line ) {
									echo esc_html( $line ) . "\n";
								}
							} else {
								echo 'No hay registros recientes.';
							}
							?>
						</div>
					</section>
				</div>

				<!-- Botón Guardar - Fuera del Card y visible en pestañas de configuración -->
				<div class="pcc-form-footer" id="pcc-save-footer" style="margin-top: 20px; <?php echo ( $requested_tab === 'logs' || $requested_tab === 'sync' ) ? 'display:none;' : ''; ?>">
					<?php submit_button( 'Guardar configuración', 'primary', 'submit', false ); ?>
				</div>
			</form>
		</main>
	</div>
</div>
