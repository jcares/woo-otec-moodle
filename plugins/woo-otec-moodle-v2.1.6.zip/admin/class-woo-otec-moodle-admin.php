<?php
/**
 * Orquestador del panel de administración.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Clase que gestiona el panel de administración.
 * Centraliza la configuración, AJAX y renderizado de vistas.
 */
final class Woo_OTEC_Moodle_Admin {

	/** @var Woo_OTEC_Moodle_Admin|null */
	private static ?Woo_OTEC_Moodle_Admin $instance = null;

	/**
	 * Obtiene la instancia única.
	 */
	public static function instance(): Woo_OTEC_Moodle_Admin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
	}

	/**
	 * Inicia el panel de administración.
	 */
	public function boot(): void {
		if ( ! is_admin() ) {
			return;
		}

		// Menú y Ajustes.
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		// AJAX y Post Handlers.
		add_action( 'admin_post_woo_otec_moodle_run_sync', array( $this, 'handle_manual_sync' ) );
		add_action( 'wp_ajax_woo_otec_moodle_email_preview', array( $this, 'handle_email_preview' ) );
		add_action( 'wp_ajax_woo_otec_moodle_send_test_email', array( $this, 'handle_send_test_email' ) );
		add_action( 'wp_ajax_woo_otec_moodle_template_fields', array( $this, 'handle_template_fields_ajax' ) );
		add_action( 'wp_ajax_woo_otec_moodle_get_categories', array( $this, 'handle_get_categories' ) );
		add_action( 'wp_ajax_woo_otec_moodle_get_teachers', array( $this, 'handle_get_teachers' ) );
		add_action( 'wp_ajax_woo_otec_moodle_get_courses', array( $this, 'handle_get_courses' ) );
		add_action( 'wp_ajax_woo_otec_moodle_execute_wizard_sync', array( $this, 'handle_execute_wizard_sync' ) );
		add_action( 'wp_ajax_woo_otec_moodle_test_sso', array( $this, 'handle_test_sso' ) );
		add_action( 'wp_ajax_woo_otec_moodle_export_logs', array( $this, 'handle_export_logs' ) );
		add_action( 'wp_ajax_woo_otec_moodle_generate_zip', array( $this, 'handle_generate_zip' ) );
	}

	/**
	 * Registra el menú de administración.
	 */
	public function register_menu(): void {
		add_menu_page( 'PCC WooOTEC Chile', 'PCC WooOTEC Chile', 'manage_options', 'woo-otec-moodle', array( $this, 'render_settings_page' ), 'dashicons-welcome-learn-more', 25 );
		add_submenu_page( 'woo-otec-moodle', 'Configuracion', 'Configuracion', 'manage_options', 'woo-otec-moodle', array( $this, 'render_settings_page' ) );
		add_submenu_page( 'woo-otec-moodle', 'Sincronizacion', 'Sincronizacion', 'manage_options', 'woo-otec-moodle-sync', array( $this, 'render_sync_page' ) );
		add_submenu_page( 'woo-otec-moodle', 'Logs', 'Logs', 'manage_options', 'woo-otec-moodle-logs', array( $this, 'render_logs_page' ) );
	}

	/**
	 * Registra los ajustes del plugin (Settings API).
	 */
	public function register_settings(): void {
		$fields = array(
			'moodle_url' => 'esc_url_raw', 'moodle_token' => 'sanitize_text_field', 'student_role_id' => 'absint',
			'default_price' => 'sanitize_text_field', 'default_instructor' => 'sanitize_text_field',
			'fallback_description' => 'sanitize_textarea_field', 'default_image_id' => 'absint',
			'sso_base_url' => 'esc_url_raw', 'github_repo' => 'sanitize_text_field', 'github_release_url' => 'esc_url_raw',
			'email_from_address' => 'sanitize_email', 'email_from_name' => 'sanitize_text_field',
			'email_subject' => 'sanitize_text_field', 'email_template' => array( $this, 'sanitize_email_template' ),
			'email_test_recipient' => 'sanitize_email', 'retry_limit' => 'absint',
			'pcc_color_primary' => 'sanitize_hex_color', 'pcc_color_secondary' => 'sanitize_hex_color',
			'pcc_color_text' => 'sanitize_hex_color', 'pcc_color_accent' => 'sanitize_hex_color',
			'template_style' => 'sanitize_text_field', 'template_reference' => 'absint',
		);

		register_setting( 'woo_otec_moodle_settings', 'woo_otec_moodle_template_fields', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_array' ), 'default' => array() ) );
		register_setting( 'woo_otec_moodle_settings', 'woo_otec_moodle_mappings', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_mappings' ), 'default' => array() ) );

		foreach ( $fields as $field => $callback ) {
			register_setting( 'woo_otec_moodle_settings', 'woo_otec_moodle_' . $field, array( 'sanitize_callback' => $callback ) );
		}

		foreach ( array( 'sso_enabled', 'auto_update', 'redirect_after_purchase', 'debug_enabled', 'email_enabled' ) as $field ) {
			register_setting( 'woo_otec_moodle_settings', 'woo_otec_moodle_' . $field, array( 'sanitize_callback' => array( $this, 'sanitize_checkbox' ) ) );
		}
	}

	/**
	 * Encola assets.
	 */
	public function enqueue_assets( string $hook ): void {
		if ( false === strpos( $hook, 'woo-otec-moodle' ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'woo-otec-modern-ui', WOO_OTEC_MOODLE_URL . 'assets/admin/css/modern-ui.css', array(), WOO_OTEC_MOODLE_VERSION );
		wp_enqueue_script( 'woo-otec-modern-ui', WOO_OTEC_MOODLE_URL . 'assets/admin/js/modern-ui.js', array( 'jquery' ), WOO_OTEC_MOODLE_VERSION, true );
		wp_localize_script( 'woo-otec-modern-ui', 'wooOtecMoodleAdmin', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'woo_otec_moodle_sync_stage' ),
			'emailNonce' => wp_create_nonce( 'woo_otec_moodle_email_tools' ),
			'defaultTab' => $this->get_default_tab(),
			'templateNonce' => wp_create_nonce( 'woo_otec_moodle_template_fields' ),
		) );
	}

	// -------------------------------------------------------------------------
	// Renderizado
	// -------------------------------------------------------------------------

	public function render_settings_page(): void {
		$this->render_view( 'settings-page.php', array(
			'core' => Woo_OTEC_Moodle_Core::instance(),
			'last_sync' => Woo_OTEC_Moodle_Core::instance()->get_option( 'last_sync', array() ),
			'connection_ok' => Woo_OTEC_Moodle_Core::instance()->make( 'api' )->test_connection(),
			'sync_log' => Woo_OTEC_Moodle_Logger::read_tail( Woo_OTEC_Moodle_Logger::SYNC_LOG ),
			'error_log' => Woo_OTEC_Moodle_Logger::read_tail( Woo_OTEC_Moodle_Logger::ERROR_LOG ),
			'active_tab' => $this->get_default_tab(),
			'status' => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '',
		) );
	}

	public function render_sync_page(): void {
		wp_safe_redirect( add_query_arg( array( 'page' => 'woo-otec-moodle', 'tab' => 'sync' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function render_logs_page(): void {
		wp_safe_redirect( add_query_arg( array( 'page' => 'woo-otec-moodle', 'tab' => 'sync' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	private function render_view( string $view, array $data = array() ): void {
		$path = WOO_OTEC_MOODLE_PATH . 'admin/views/' . $view;
		if ( file_exists( $path ) ) {
			extract( $data ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
			include $path;
		}
	}

	private function get_default_tab(): string {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general';
		return in_array( $tab, array( 'general', 'sync', 'sso', 'templates', 'emails', 'logs' ), true ) ? $tab : 'general';
	}

	// -------------------------------------------------------------------------
	// Handlers AJAX / POST
	// -------------------------------------------------------------------------

	public function handle_manual_sync(): void {
		check_admin_referer( 'woo_otec_moodle_run_sync' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No autorizado.' );
		}
		$res = Woo_OTEC_Moodle_Core::instance()->make( 'sync' )->run( true );
		wp_safe_redirect( add_query_arg( array( 'page' => 'woo-otec-moodle', 'tab' => 'sync', 'status' => $res['status'] ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_email_preview(): void {
		check_ajax_referer( 'woo_otec_moodle_email_tools', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		wp_send_json_success( array( 'html' => Woo_OTEC_Moodle_Core::instance()->make( 'enroll' )->render_email_preview() ) );
	}

	public function handle_send_test_email(): void {
		check_ajax_referer( 'woo_otec_moodle_email_tools', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$recipient = sanitize_email( wp_unslash( $_POST['recipient'] ?? '' ) );
		$res = Woo_OTEC_Moodle_Core::instance()->make( 'enroll' )->send_test_email( $recipient );
		is_wp_error( $res ) ? wp_send_json_error( $res->get_error_message() ) : wp_send_json_success( 'Correo enviado.' );
	}

	public function handle_template_fields_ajax(): void {
		check_ajax_referer( 'woo_otec_moodle_template_fields', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$pid = absint( $_POST['product_id'] ?? 0 );
		if ( $pid <= 0 ) {
			wp_send_json_error( 'Producto no válido.' );
		}
		$selected = (array) Woo_OTEC_Moodle_Core::instance()->get_option( 'template_fields', array() );
		wp_send_json_success( array( 'html' => $this->render_template_fields_markup( $pid, $selected, false ) ) );
	}

	public function handle_get_categories(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$api = Woo_OTEC_Moodle_Core::instance()->make( 'api' );
		$cats = $api->get_categories();
		if ( is_wp_error( $cats ) ) {
			wp_send_json_error( $cats->get_error_message() );
		}
		$options = array();
		foreach ( (array) $cats as $c ) {
			if ( isset( $c->id, $c->name ) ) {
				$options[] = array( 'id' => (int) $c->id, 'name' => (string) $c->name );
			}
		}
		wp_send_json_success( array( 'categories' => $options ) );
	}

	public function handle_get_teachers(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$cat_ids = array_map( 'absint', (array) wp_unslash( $_POST['categories'] ?? array() ) );
		$api = Woo_OTEC_Moodle_Core::instance()->make( 'api' );
		$teachers = array();
		foreach ( $cat_ids as $cid ) {
			$courses = $api->get_courses_by_category( $cid );
			if ( ! is_wp_error( $courses ) ) {
				foreach ( (array) $courses as $course ) {
					$names = $api->get_course_teachers( (int) $course->id );
					foreach ( $names as $n ) {
						$teachers[ $n ] = $n;
					}
				}
			}
		}
		wp_send_json_success( array( 'teachers' => array_values( $teachers ) ) );
	}

	public function handle_get_courses(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$cat_ids = array_map( 'absint', (array) wp_unslash( $_POST['categories'] ?? array() ) );
		$api = Woo_OTEC_Moodle_Core::instance()->make( 'api' );
		$all_courses = array();
		foreach ( $cat_ids as $cid ) {
			$res = $api->get_courses_by_category( $cid );
			if ( ! is_wp_error( $res ) ) {
				foreach ( (array) $res as $c ) {
					if ( (int) $c->id > 1 ) {
						$all_courses[] = $c;
					}
				}
			}
		}
		wp_send_json_success( array( 'courses' => $all_courses ) );
	}

	public function handle_execute_wizard_sync(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$courses = map_deep( wp_unslash( $_POST['courses'] ?? array() ), 'sanitize_text_field' );
		$sync = Woo_OTEC_Moodle_Core::instance()->make( 'sync' );
		$results = array( 'created' => 0, 'updated' => 0, 'errors' => 0 );
		foreach ( $courses as $c ) {
			$res = $sync->sync_single_course( $c );
			if ( 'created' === $res['status'] ) {
				$results['created']++;
			} elseif ( 'updated' === $res['status'] ) {
				$results['updated']++;
			} else {
				$results['errors']++;
			}
		}
		wp_send_json_success( $results );
	}

	public function handle_test_sso(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$url = esc_url_raw( wp_unslash( $_POST['url'] ?? '' ) );
		$res = wp_remote_get( $url );
		if ( is_wp_error( $res ) ) {
			wp_send_json_error( 'Error: ' . $res->get_error_message() );
		}
		wp_send_json_success( 'Conexión exitosa.' );
	}

	public function handle_export_logs(): void {
		check_admin_referer( 'woo_otec_moodle_export_logs', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No autorizado.' );
		}
		$log = Woo_OTEC_Moodle_Logger::read_full( Woo_OTEC_Moodle_Logger::ERROR_LOG );
		header( 'Content-Type: text/plain' );
		header( 'Content-Disposition: attachment; filename="woo-otec-logs-' . gmdate( 'Y-m-d-His' ) . '.txt"' );
		echo esc_html( $log );
		exit;
	}

	public function handle_generate_zip(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		wp_send_json_success( array( 'url' => '#' ) );
	}

	// -------------------------------------------------------------------------
	// Helpers / Sanitización
	// -------------------------------------------------------------------------

	public function sanitize_array( $v ) { return is_array( $v ) ? array_map( 'sanitize_text_field', $v ) : array(); }
	public function sanitize_checkbox( $v ) { return ( ! empty( $v ) && 'no' !== $v ) ? 'yes' : 'no'; }
	public function sanitize_email_template( $v ) { return wp_kses( (string) $v, Woo_OTEC_Moodle_Core::instance()->make( 'mailer' )->get_email_allowed_html() ); }
	public function sanitize_mappings( $v ) {
		if ( ! is_array( $v ) ) return array();
		$s = array();
		foreach ( $v as $k => $c ) {
			$s[ sanitize_key( $k ) ] = array(
				'target' => sanitize_text_field( $c['target'] ?? '' ),
				'label' => sanitize_text_field( $c['label'] ?? '' ),
				'enabled' => ! empty( $c['enabled'] ) ? 'yes' : 'no',
			);
		}
		return $s;
	}

	public function get_template_reference_products(): array {
		return function_exists( 'wc_get_products' ) ? wc_get_products( array( 'limit' => 200, 'meta_key' => '_moodle_id', 'meta_compare' => 'EXISTS' ) ) : array();
	}

	public function render_template_fields_markup( int $pid, array $selected, bool $echo = true ): string {
		$meta = get_post_meta( $pid );
		if ( ! is_array( $meta ) ) return '';
		$keys = array_keys( $meta );
		ob_start();
		echo '<div class="pcc-template-fields-grid">';
		foreach ( $keys as $k ) {
			if ( str_starts_with( $k, '_' ) && ! in_array( $k, array( '_instructor', '_start_date', '_end_date', '_duration', '_modality' ) ) ) continue;
			$checked = in_array( $k, $selected, true );
			echo '<label class="pcc-meta-checkbox"><input type="checkbox" name="woo_otec_moodle_template_fields[]" value="' . esc_attr( $k ) . '" ' . checked( $checked, true, false ) . '><span>' . esc_html( $k ) . '</span></label>';
		}
		echo '</div>';
		$html = (string) ob_get_clean();
		if ( $echo ) echo wp_kses_post( $html );
		return $html;
	}
}
