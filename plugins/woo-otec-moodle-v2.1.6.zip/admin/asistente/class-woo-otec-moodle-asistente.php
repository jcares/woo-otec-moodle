<?php
/**
 * Clase que gestiona el asistente de configuración inicial.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Clase que gestiona el asistente de configuración inicial.
 */
final class Woo_OTEC_Moodle_Asistente {

	/**
	 * Instancia única de la clase.
	 *
	 * @var Woo_OTEC_Moodle_Asistente|null
	 */
	private static ?Woo_OTEC_Moodle_Asistente $instance = null;

	/**
	 * Obtiene la instancia única de la clase.
	 *
	 * @return Woo_OTEC_Moodle_Asistente
	 */
	public static function instance(): Woo_OTEC_Moodle_Asistente {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor privado.
	 */
	private function __construct() {
	}

	/**
	 * Inicia los ganchos del asistente.
	 */
	public function boot(): void {
		add_action( 'admin_menu', array( $this, 'add_wizard_page' ) );
		add_action( 'admin_post_woo_otec_moodle_asistente_save', array( $this, 'handle_save' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Registra la página del asistente en el menú.
	 */
	public function add_wizard_page(): void {
		add_submenu_page(
			null, // Oculta el menú lateral.
			'Asistente Moodle',
			'Asistente Moodle',
			'manage_options',
			'woo-otec-asistente',
			array( $this, 'render_wizard' )
		);
	}

	/**
	 * Encola los scripts y estilos del asistente.
	 *
	 * @param string $hook Gancho de la página actual.
	 */
	public function enqueue_assets( string $hook ): void {
		if ( false === strpos( $hook, 'woo-otec-asistente' ) ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_style( 'woo-otec-wizard-css', WOO_OTEC_MOODLE_URL . 'admin/asistente/assets/css/asistente.css', array(), WOO_OTEC_MOODLE_VERSION );
	}

	/**
	 * Renderiza la vista del asistente.
	 */
	public function render_wizard(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No tienes permisos suficientes para acceder a esta página.' );
		}

		$step = isset( $_GET['step'] ) ? (int) $_GET['step'] : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$step = max( 1, min( 5, $step ) );

		$view_path = WOO_OTEC_MOODLE_PATH . 'admin/asistente/views/plantilla.php';
		if ( file_exists( $view_path ) ) {
			include $view_path;
		} else {
			echo '<div class="notice notice-error"><p>No se encontró la plantilla principal del asistente.</p></div>';
		}
	}

	/**
	 * Maneja el guardado de datos del asistente.
	 */
	public function handle_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No autorizado.' );
		}

		check_admin_referer( 'woo_otec_moodle_asistente_save', 'wizard_nonce' );

		$step = isset( $_POST['step'] ) ? (int) $_POST['step'] : 1;

		if ( 1 === $step ) {
			// Guardar URL & Token.
			if ( isset( $_POST['moodle_url'] ) ) {
				Woo_OTEC_Moodle_Core::instance()->update_option( 'moodle_url', esc_url_raw( wp_unslash( $_POST['moodle_url'] ) ) );
			}
			if ( isset( $_POST['moodle_token'] ) ) {
				Woo_OTEC_Moodle_Core::instance()->update_option( 'moodle_token', sanitize_text_field( wp_unslash( $_POST['moodle_token'] ) ) );
			}
			$next_step = 2;
		} elseif ( 2 === $step ) {
			// Validar conexión y avanzar.
			$next_step = 3;
		} elseif ( 3 === $step ) {
			// Guardar ID del Rol.
			if ( isset( $_POST['student_role_id'] ) ) {
				Woo_OTEC_Moodle_Core::instance()->update_option( 'student_role_id', absint( wp_unslash( $_POST['student_role_id'] ) ) );
			}
			$next_step = 4;
		} elseif ( 4 === $step ) {
			// Guardar Parámetros Base.
			if ( isset( $_POST['default_price'] ) ) {
				Woo_OTEC_Moodle_Core::instance()->update_option( 'default_price', sanitize_text_field( wp_unslash( $_POST['default_price'] ) ) );
			}
			if ( isset( $_POST['default_instructor'] ) ) {
				Woo_OTEC_Moodle_Core::instance()->update_option( 'default_instructor', sanitize_text_field( wp_unslash( $_POST['default_instructor'] ) ) );
			}
			if ( isset( $_POST['default_image_id'] ) ) {
				Woo_OTEC_Moodle_Core::instance()->update_option( 'default_image_id', absint( wp_unslash( $_POST['default_image_id'] ) ) );
			}
			$next_step = 5;
		} else {
			// Finalizar: Volver al Dashboard.
			$redirect_url = admin_url( 'admin.php?page=woo-otec-moodle' );
			wp_safe_redirect( $redirect_url );
			exit;
		}

		$redirect_url = admin_url( 'admin.php?page=woo-otec-asistente&step=' . $next_step );
		wp_safe_redirect( $redirect_url );
		exit;
	}
}
