<?php
/**
 * Clase que gestiona la inscripción de alumnos en Moodle.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Clase que gestiona la inscripción de alumnos en Moodle.
 */
final class Woo_OTEC_Moodle_Enroll {

	/**
	 * Gancho para el reintento de inscripción.
	 */
	public const RETRY_HOOK = 'woo_otec_moodle_retry_enrollment';

	/**
	 * Instancia única de la clase.
	 *
	 * @var Woo_OTEC_Moodle_Enroll|null
	 */
	private static ?Woo_OTEC_Moodle_Enroll $instance = null;

	/**
	 * Obtiene la instancia única de la clase.
	 *
	 * @return Woo_OTEC_Moodle_Enroll
	 */
	public static function instance(): Woo_OTEC_Moodle_Enroll {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor privado.
	 */
	private function __construct() {
	}

	/**
	 * Inicia los ganchos de inscripción.
	 */
	public function boot(): void {
		add_action( 'woocommerce_order_status_completed', array( $this, 'handle_completed_order' ) );
		add_action( 'woocommerce_order_status_processing', array( $this, 'handle_completed_order' ) );
		add_action( 'template_redirect', array( $this, 'maybe_redirect_after_purchase' ) );
		add_action( self::RETRY_HOOK, array( $this, 'retry_enrollment' ) );
		add_action( 'woocommerce_thankyou', array( $this, 'render_thankyou_actions' ), 20 );
		add_action( 'woocommerce_order_details_after_order_table', array( $this, 'render_order_access_buttons' ) );
		add_filter( 'woocommerce_order_actions', array( $this, 'register_order_actions' ) );
		add_action( 'woocommerce_order_action_pcc_resend_course_email', array( $this, 'handle_resend_order_email' ) );
	}

	/**
	 * Maneja una orden completada o en procesamiento.
	 *
	 * @param int $order_id ID de la orden.
	 */
	public function handle_completed_order( int $order_id ): void {
		Woo_OTEC_Moodle_Logger::info( 'Hook de orden completada (o processing) disparado', array( 'order_id' => $order_id ) );
		$this->process_order( $order_id, false, false );
	}

	/**
	 * Reintenta la inscripción de una orden.
	 *
	 * @param int $order_id ID de la orden.
	 */
	public function retry_enrollment( int $order_id ): void {
		$this->process_order( (int) $order_id, false, true );
	}

	/**
	 * Maneja el reenvío manual del correo de acceso.
	 *
	 * @param mixed $order Objeto de la orden (WC_Order).
	 */
	public function handle_resend_order_email( $order ): void {
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$this->send_order_access_email( $order, true );
		$order->add_order_note( 'PCC WooOTEC: correo de acceso reenviado manualmente.' );
		$order->save();
	}

	/**
	 * Redirige al alumno tras la compra si está configurado.
	 */
	public function maybe_redirect_after_purchase(): void {
		if ( 'yes' !== Woo_OTEC_Moodle_Core::instance()->get_option( 'redirect_after_purchase', 'no' ) ) {
			return;
		}

		if ( ! function_exists( 'is_order_received_page' ) || ! is_order_received_page() ) {
			return;
		}

		$order_id = absint( get_query_var( 'order-received' ) );
		if ( $order_id <= 0 ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$url = (string) $order->get_meta( '_moodle_access_url' );
		if ( '' !== $url ) {
			wp_safe_redirect( $url );
			exit;
		}
	}

	/**
	 * Renderiza una vista previa del correo.
	 *
	 * @return string
	 */
	public function render_email_preview(): string {
		$sample = $this->get_sample_email_data();
		return Woo_OTEC_Moodle_Core::instance()->make( 'mailer' )->render_template( $sample, true );
	}

	/**
	 * Envía un correo de prueba.
	 *
	 * @param string $recipient Correo del destinatario.
	 * @return bool|WP_Error
	 */
	public function send_test_email( string $recipient ): bool|WP_Error {
		$recipient = sanitize_email( $recipient );
		if ( '' === $recipient ) {
			return new WP_Error( 'pcc_invalid_test_email', 'Debes indicar un correo de prueba valido.' );
		}

		$subject = Woo_OTEC_Moodle_Core::instance()->make( 'mailer' )->render_subject( $this->get_sample_email_data() );
		$body    = $this->render_email_preview();
		$sent    = Woo_OTEC_Moodle_Core::instance()->make( 'mailer' )->send( $recipient, $subject, $body );

		if ( ! $sent ) {
			Woo_OTEC_Moodle_Logger::error( 'Fallo envio de correo de prueba', array( 'recipient' => $recipient ) );
			return new WP_Error( 'pcc_test_email_failed', 'No fue posible enviar el correo de prueba.' );
		}

		Woo_OTEC_Moodle_Logger::info( 'Correo de prueba enviado', array( 'recipient' => $recipient ) );
		return true;
	}

	/**
	 * Renderiza acciones en la página de gracias.
	 *
	 * @param int $order_id ID de la orden.
	 */
	public function render_thankyou_actions( int $order_id ): void {
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$this->render_access_box( $order );
	}

	/**
	 * Renderiza botones de acceso en los detalles de la orden.
	 *
	 * @param mixed $order Objeto (WC_Order) o ID de la orden.
	 */
	public function render_order_access_buttons( $order ): void {
		if ( is_numeric( $order ) ) {
			$order = wc_get_order( (int) $order );
		}

		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$this->render_access_box( $order );
	}

	/**
	 * Registra acciones personalizadas en la orden.
	 *
	 * @param array $actions Acciones existentes.
	 * @return array
	 */
	public function register_order_actions( array $actions ): array {
		$actions['pcc_resend_course_email'] = 'PCC: reenviar correo de acceso';
		return $actions;
	}

	/**
	 * Procesa una orden para inscribir al alumno.
	 *
	 * @param int  $order_id    ID de la orden.
	 * @param bool $force_email Si se debe forzar el envío del correo.
	 * @param bool $is_retry    Si es un reintento.
	 * @return bool
	 */
	private function process_order( int $order_id, bool $force_email = false, bool $is_retry = false ): bool {
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return false;
		}

		if ( ! in_array( $order->get_status(), array( 'completed', 'processing' ), true ) ) {
			return false;
		}

		Woo_OTEC_Moodle_Logger::info(
			'Compra detectada',
			array(
				'order_id' => $order_id,
				'retry'    => $is_retry,
				'status'   => $order->get_status(),
			)
		);

		$learner = $this->resolve_learner_data( $order );
		if ( ! $learner ) {
			Woo_OTEC_Moodle_Logger::error( 'No fue posible resolver datos del alumno', array( 'order_id' => $order_id ) );
			return false;
		}

		$course_ids = $this->get_order_course_ids( $order );
		if ( empty( $course_ids ) ) {
			Woo_OTEC_Moodle_Logger::info( 'La orden no contiene cursos de Moodle. Saltando matricula.', array( 'order_id' => $order_id ) );
			$order->update_meta_data( '_pcc_moodle_enrollment_complete', '1' );
			$order->save();
			return true;
		}

		$moodle_result = Woo_OTEC_Moodle_Core::instance()->make( 'api' )->get_or_create_user( $learner );
		if ( is_wp_error( $moodle_result ) ) {
			Woo_OTEC_Moodle_Logger::error(
				'Error al crear/reutilizar usuario Moodle',
				array(
					'order_id' => $order_id,
					'error'    => $moodle_result->get_error_message(),
				)
			);
			$this->schedule_retry( $order );
			return false;
		}

		$moodle_user_id = (int) ( $moodle_result['id'] ?? 0 );
		if ( ! empty( $learner['wp_user_id'] ) ) {
			update_user_meta( (int) $learner['wp_user_id'], '_pcc_moodle_user_id', $moodle_user_id );
		}

		$order->update_meta_data( '_pcc_moodle_user_id', (string) $moodle_user_id );

		if ( ! empty( $moodle_result['created'] ) ) {
			Woo_OTEC_Moodle_Logger::info(
				'Usuario Moodle creado',
				array(
					'order_id'       => $order_id,
					'email'          => $learner['email'],
					'moodle_user_id' => $moodle_user_id,
				)
			);
		} else {
			Woo_OTEC_Moodle_Logger::info(
				'Usuario Moodle reutilizado',
				array(
					'order_id'       => $order_id,
					'email'          => $learner['email'],
					'moodle_user_id' => $moodle_user_id,
				)
			);
		}

		$already = $order->get_meta( '_pcc_moodle_enrolled_courses' );
		if ( ! is_array( $already ) ) {
			$already = array();
		}

		$enrolled = array_values( array_unique( array_map( 'intval', $already ) ) );
		$failed   = array();

		foreach ( $course_ids as $course_id ) {
			if ( in_array( $course_id, $enrolled, true ) ) {
				continue;
			}

			$enroll_ok = Woo_OTEC_Moodle_Core::instance()->make( 'api' )->enroll_user( $moodle_user_id, $course_id );
			if ( $enroll_ok ) {
				$enrolled[] = $course_id;
				Woo_OTEC_Moodle_Logger::info(
					'Matricula exitosa',
					array(
						'order_id'       => $order_id,
						'course_id'      => $course_id,
						'moodle_user_id' => $moodle_user_id,
					)
				);
			} else {
				$failed[] = $course_id;
				Woo_OTEC_Moodle_Logger::error(
					'Matricula fallida',
					array(
						'order_id'       => $order_id,
						'course_id'      => $course_id,
						'moodle_user_id' => $moodle_user_id,
					)
				);
			}
		}

		$urls = Woo_OTEC_Moodle_SSO::instance()->store_order_urls( $order, $this->build_virtual_wp_user( $learner ), $enrolled );
		$order->update_meta_data( '_pcc_moodle_enrolled_courses', array_values( array_unique( $enrolled ) ) );
		$order->update_meta_data( '_pcc_moodle_enrollment_complete', empty( $failed ) ? '1' : '0' );
		$order->update_meta_data(
			'_pcc_moodle_enrollment_last',
			array(
				'enrolled' => array_values( array_unique( $enrolled ) ),
				'failed'   => array_values( array_unique( $failed ) ),
			)
		);
		$order->save();

		if ( ! empty( $failed ) ) {
			$this->schedule_retry( $order );
			return false;
		}

		$this->clear_retry( $order );
		$this->send_order_access_email( $order, $force_email, $learner, $moodle_result['password'] ?? null, $urls );
		return true;
	}

	/**
	 * Resuelve los datos del alumno a partir de la orden.
	 *
	 * @param mixed $order Objeto de la orden (WC_Order).
	 * @return array|false
	 */
	private function resolve_learner_data( $order ): array|false {
		if ( ! $order instanceof WC_Order ) {
			return false;
		}

		$user_id = (int) $order->get_user_id();
		if ( $user_id > 0 ) {
			$user = get_userdata( $user_id );
			if ( $user instanceof WP_User ) {
				return array(
					'wp_user_id' => $user->ID,
					'firstname'  => '' !== $user->first_name ? $user->first_name : $order->get_billing_first_name(),
					'lastname'   => '' !== $user->last_name ? $user->last_name : $order->get_billing_last_name(),
					'email'      => $user->user_email,
					'display'    => $user->display_name,
				);
			}
		}

		$email = sanitize_email( (string) $order->get_billing_email() );
		if ( '' === $email ) {
			return false;
		}

		$existing = get_user_by( 'email', $email );
		if ( $existing instanceof WP_User ) {
			return array(
				'wp_user_id' => $existing->ID,
				'firstname'  => '' !== $existing->first_name ? $existing->first_name : $order->get_billing_first_name(),
				'lastname'   => '' !== $existing->last_name ? $existing->last_name : $order->get_billing_last_name(),
				'email'      => $existing->user_email,
				'display'    => $existing->display_name,
			);
		}

		$first_name = $order->get_billing_first_name();
		$last_name  = $order->get_billing_last_name();

		return array(
			'wp_user_id' => 0,
			'firstname'  => $first_name ? $first_name : 'Alumno',
			'lastname'   => $last_name ? $last_name : 'Alumno',
			'email'      => $email,
			'display'    => trim( (string) ( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ),
		);
	}

	/**
	 * Construye un objeto WP_User virtual para el alumno.
	 *
	 * @param array $learner Datos del alumno.
	 * @return WP_User
	 */
	private function build_virtual_wp_user( array $learner ): WP_User {
		$user               = new WP_User();
		$user->ID           = (int) ( $learner['wp_user_id'] ?? 0 );
		$user->user_email   = (string) ( $learner['email'] ?? '' );
		$user->first_name   = (string) ( $learner['firstname'] ?? '' );
		$user->last_name    = (string) ( $learner['lastname'] ?? '' );
		$user->display_name = (string) ( $learner['display'] ?? trim( $user->first_name . ' ' . $user->last_name ) );
		return $user;
	}

	/**
	 * Obtiene los IDs de los cursos de Moodle en la orden.
	 *
	 * @param mixed $order Objeto de la orden (WC_Order).
	 * @return array
	 */
	private function get_order_course_ids( $order ): array {
		if ( ! $order instanceof WC_Order ) {
			return array();
		}

		$course_ids = array();

		/* @var \WC_Order_Item $item */
		foreach ( $order->get_items() as $item ) {
			$product_id = (int) $item->get_product_id();
			$moodle_id  = (int) get_post_meta( $product_id, '_moodle_id', true );
			if ( $moodle_id > 0 ) {
				$course_ids[ $moodle_id ] = $moodle_id;
			}
		}

		return array_values( $course_ids );
	}

	/**
	 * Programa un reintento de inscripción.
	 *
	 * @param mixed $order Objeto de la orden (WC_Order).
	 */
	private function schedule_retry( $order ): void {
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$limit    = max( 1, (int) Woo_OTEC_Moodle_Core::instance()->get_option( 'retry_limit', 3 ) );
		$attempts = (int) $order->get_meta( '_pcc_retry_attempts' );

		if ( $attempts >= $limit ) {
			return;
		}

		++$attempts;
		$order->update_meta_data( '_pcc_retry_attempts', (string) $attempts );
		$order->save();

		wp_schedule_single_event( time() + ( 5 * MINUTE_IN_SECONDS ), self::RETRY_HOOK, array( (int) $order->get_id() ) );
	}

	/**
	 * Limpia los reintentos de una orden.
	 *
	 * @param mixed $order Objeto de la orden (WC_Order).
	 */
	private function clear_retry( $order ): void {
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$order->delete_meta_data( '_pcc_retry_attempts' );
		$order->save();
	}

	/**
	 * Envía el correo de acceso al curso.
	 *
	 * @param mixed       $order    Objeto de la orden (WC_Order).
	 * @param bool        $force    Si se debe forzar el envío.
	 * @param array|null  $learner  Datos del alumno.
	 * @param string|null $password Contraseña generada.
	 * @param array|null  $urls     URLs de acceso.
	 * @return bool
	 */
	private function send_order_access_email( $order, bool $force = false, ?array $learner = null, ?string $password = null, ?array $urls = null ): bool {
		if ( ! $order instanceof WC_Order ) {
			return false;
		}

		$email_enabled = Woo_OTEC_Moodle_Core::instance()->get_option( 'email_enabled', 'yes' );

		if ( 'yes' !== $email_enabled ) {
			Woo_OTEC_Moodle_Logger::info( 'Envio de email saltado: deshabilitado en configuracion', array( 'order_id' => $order->get_id() ) );
			return false;
		}

		if ( ! $force && ! $order->get_meta( '_pcc_moodle_enrollment_complete' ) ) {
			Woo_OTEC_Moodle_Logger::info( 'Envio de email saltado: matricula aun no completada', array( 'order_id' => $order->get_id() ) );
			return false;
		}

		if ( ! $force && $order->get_meta( '_pcc_access_email_sent' ) ) {
			Woo_OTEC_Moodle_Logger::info( 'Envio de email saltado: ya fue enviado anteriormente', array( 'order_id' => $order->get_id() ) );
			return false;
		}

		$learner = $learner ? $learner : $this->resolve_learner_data( $order );
		if ( ! $learner ) {
			Woo_OTEC_Moodle_Logger::error( 'No se pudo enviar email: no hay datos del alumno', array( 'order_id' => $order->get_id() ) );
			return false;
		}

		$urls    = is_array( $urls ) ? $urls : (array) $order->get_meta( '_pcc_moodle_access_urls' );
		$data    = $this->build_email_data( $order, $learner, $password, $urls );
		$subject = Woo_OTEC_Moodle_Core::instance()->make( 'mailer' )->render_subject( $data );
		$body    = Woo_OTEC_Moodle_Core::instance()->make( 'mailer' )->render_template( $data, false );

		Woo_OTEC_Moodle_Logger::info(
			'Intentando enviar email de acceso',
			array(
				'order_id' => $order->get_id(),
				'email'    => $learner['email'],
			)
		);
		$sent = Woo_OTEC_Moodle_Core::instance()->make( 'mailer' )->send( (string) $learner['email'], $subject, $body );

		if ( $sent ) {
			$order->update_meta_data( '_pcc_access_email_sent', '1' );
			if ( null !== $password && '' !== $password ) {
				$order->update_meta_data( '_pcc_generated_password', $password );
			}
			$order->save();
			Woo_OTEC_Moodle_Logger::info(
				'Correo de acceso enviado exitosamente',
				array(
					'order_id' => $order->get_id(),
					'email'    => $learner['email'],
				)
			);
			return true;
		}

		Woo_OTEC_Moodle_Logger::error(
			'Fallo critico al enviar correo de acceso (wp_mail devolvio false)',
			array(
				'order_id' => $order->get_id(),
				'email'    => $learner['email'],
			)
		);
		return false;
	}

	/**
	 * Construye los datos para el correo de acceso.
	 *
	 * @param mixed       $order    Objeto de la orden (WC_Order).
	 * @param array       $learner  Datos del alumno.
	 * @param string|null $password Contraseña generada.
	 * @param array       $urls     URLs de acceso.
	 * @return array
	 */
	private function build_email_data( $order, array $learner, ?string $password, array $urls ): array {
		if ( ! $order instanceof WC_Order ) {
			return array();
		}

		$course_names = array();
		/* @var \WC_Order_Item $item */
		foreach ( $order->get_items() as $item ) {
			$product_id = (int) $item->get_product_id();
			if ( (int) get_post_meta( $product_id, '_moodle_id', true ) > 0 ) {
				$course_names[] = $item->get_name();
			}
		}

		return array(
			'nombre'     => trim( (string) ( ( $learner['firstname'] ?? '' ) . ' ' . ( $learner['lastname'] ?? '' ) ) ),
			'email'      => (string) ( $learner['email'] ?? '' ),
			'password'   => ( null !== $password && '' !== $password ) ? $password : 'Usa tu contraseña actual de Moodle',
			'url_acceso' => ! empty( $urls ) ? (string) reset( $urls ) : (string) $order->get_meta( '_moodle_access_url' ),
			'cursos'     => implode( '<br>', array_map( 'esc_html', $course_names ) ),
			'sitio'      => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
		);
	}

	/**
	 * Obtiene datos de ejemplo para la previsualización del correo.
	 *
	 * @return array
	 */
	private function get_sample_email_data(): array {
		return array(
			'nombre'     => 'Alumno Demo',
			'email'      => 'alumno@example.com',
			'password'   => 'TempPassword123!',
			'url_acceso' => Woo_OTEC_Moodle_SSO::instance()->build_url( 'alumno@example.com', 123 ),
			'cursos'     => 'Curso Demo 1<br>Curso Demo 2',
			'sitio'      => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
		);
	}

	/**
	 * Renderiza una caja de acceso en el frontend.
	 *
	 * @param mixed $order Objeto de la orden (WC_Order).
	 */
	private function render_access_box( $order ): void {
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$urls       = (array) $order->get_meta( '_pcc_moodle_access_urls' );
		$single_url = (string) $order->get_meta( '_moodle_access_url' );

		if ( empty( $urls ) && '' === $single_url ) {
			return;
		}

		echo '<section class="pcc-access-box"><h2>Acceso a tus cursos</h2><p>Usa los siguientes accesos directos:</p>';

		if ( ! empty( $urls ) ) {
			echo '<ul class="pcc-access-links">';
			foreach ( $urls as $course_id => $url ) {
				echo '<li><a class="button" href="' . esc_url( (string) $url ) . '">Acceder al curso #' . (int) $course_id . '</a></li>';
			}
			echo '</ul>';
		} elseif ( '' !== $single_url ) {
			echo '<p><a class="button" href="' . esc_url( $single_url ) . '">Acceder al curso</a></p>';
		}

		echo '</section>';
	}
}
