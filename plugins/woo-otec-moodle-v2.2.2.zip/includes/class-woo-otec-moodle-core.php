<?php
/**
 * Core del plugin Woo OTEC Moodle.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Clase principal que gestiona la carga y servicios del plugin.
 */
final class Woo_OTEC_Moodle_Core {

	/**
	 * Instancia única de la clase.
	 *
	 * @var Woo_OTEC_Moodle_Core|null
	 */
	private static ?Woo_OTEC_Moodle_Core $instance = null;

	/**
	 * Valores por defecto del plugin.
	 *
	 * @var array
	 */
	private array $defaults = array();

	/**
	 * Registro de servicios.
	 *
	 * @var array<string, callable> Registro de servicios (Tarea #4)
	 */
	private array $services = array();

	/**
	 * Instancias resueltas.
	 *
	 * @var array<string, mixed> Instancias resueltas
	 */
	private array $resolved = array();

	/**
	 * Obtiene la instancia única de la clase.
	 */
	public static function instance(): Woo_OTEC_Moodle_Core {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor privado.
	 */
	private function __construct() {
		$defaults = file_exists( WOO_OTEC_MOODLE_PATH . 'config/defaults.php' )
			? require WOO_OTEC_MOODLE_PATH . 'config/defaults.php'
			: array();

		$this->defaults = is_array( $defaults ) ? $defaults : array();
	}

	/**
	 * Obtiene los valores por defecto.
	 *
	 * @return array
	 */
	public function get_defaults(): array {
		return $this->defaults;
	}

	/**
	 * Obtiene una opción del plugin.
	 *
	 * @param string $key      Nombre de la opción.
	 * @param mixed  $fallback Valor por defecto si no existe.
	 * @return mixed
	 */
	public function get_option( string $key, mixed $fallback = null ): mixed {
		$option_name = 'woo_otec_moodle_' . $key;
		$value       = get_option( $option_name, null );
		if ( null === $value ) {
			if ( array_key_exists( $key, $this->defaults ) ) {
				return $this->defaults[ $key ];
			}
			return $fallback;
		}

		return $value;
	}

	/**
	 * Actualiza una opción del plugin.
	 *
	 * @param string $key   Nombre de la opción.
	 * @param mixed  $value Nuevo valor.
	 * @return bool
	 */
	public function update_option( string $key, mixed $value ): bool {
		$option_name = 'woo_otec_moodle_' . $key;
		return update_option( $option_name, $value );
	}

	/**
	 * Inicia el plugin.
	 */
	public function boot(): void {
		$this->load_dependencies();
		$this->register_hooks();

		// Cargar administración inmediatamente si es admin.
		if ( is_admin() ) {
			if ( class_exists( 'Woo_OTEC_Moodle_Admin' ) ) {
				$this->make( 'admin' )->boot();
			}
			if ( class_exists( 'Woo_OTEC_Moodle_Asistente' ) ) {
				$this->make( 'asistente' )->boot();
			}
		}
	}

	/**
	 * Función de activación del plugin.
	 */
	public static function activate(): void {
		$core = self::instance();
		$core->load_dependencies();
		$core->register_default_options();

		if ( class_exists( 'Woo_OTEC_Moodle_Cron' ) ) {
			Woo_OTEC_Moodle_Cron::install();
		}

		if ( class_exists( 'Woo_OTEC_Moodle_Logger' ) ) {
			Woo_OTEC_Moodle_Logger::get_directory();
		}

		flush_rewrite_rules();
	}

	/**
	 * Función de desactivación del plugin.
	 */
	public static function deactivate(): void {
		if ( class_exists( 'Woo_OTEC_Moodle_Cron' ) ) {
			Woo_OTEC_Moodle_Cron::unschedule();
		}
	}

	/**
	 * Registra las opciones por defecto.
	 */
	public function register_default_options(): void {
		foreach ( $this->defaults as $key => $value ) {
			$option_name = 'woo_otec_moodle_' . $key;
			if ( get_option( $option_name, null ) === null ) {
				add_option( $option_name, $value );
			}
		}
	}

	/**
	 * Carga las dependencias del plugin.
	 */
	private function load_dependencies(): void {

		$files = array(
			'includes/class-woo-otec-moodle-exception.php',
			'includes/class-woo-otec-moodle-logger.php',
			'includes/class-woo-otec-moodle-api.php',
			'includes/class-woo-otec-moodle-mailer.php',
			'includes/class-woo-otec-moodle-mapper.php',
			'includes/class-woo-otec-moodle-sync.php',
			'includes/class-woo-otec-moodle-sso.php',
			'includes/class-woo-otec-moodle-cron.php',
			'includes/class-woo-otec-moodle-enroll.php',
			'public/class-woo-otec-moodle-frontend.php',
			'admin/class-woo-otec-moodle-settings.php',
			'admin/class-woo-otec-moodle-ajax-handler.php',
			'admin/class-woo-otec-moodle-admin.php',
			'admin/asistente/class-woo-otec-moodle-asistente.php',
		);

		foreach ( $files as $file ) {
			$path = WOO_OTEC_MOODLE_PATH . $file;
			if ( file_exists( $path ) ) {
				require_once $path;
			}
		}

		// Registrar servicios en el contenedor.
		$this->register_services();
	}

	// -------------------------------------------------------------------------
	// Contenedor de servicios (Tarea #4)
	// -------------------------------------------------------------------------

	/**
	 * Registra una fábrica de servicio.
	 *
	 * @param string   $id      Identificador del servicio.
	 * @param callable $factory Función que retorna la instancia.
	 */
	public function register( string $id, callable $factory ): void {
		$this->services[ $id ] = $factory;
		unset( $this->resolved[ $id ] ); // Invalidar caché si se re-registra.
	}

	/**
	 * Resuelve y devuelve un servicio registrado.
	 *
	 * @param string $id Identificador del servicio.
	 * @throws \RuntimeException Si el servicio no está registrado.
	 * @return mixed
	 */
	public function make( string $id ): mixed {
		if ( isset( $this->resolved[ $id ] ) ) {
			return $this->resolved[ $id ];
		}

		if ( ! isset( $this->services[ $id ] ) ) {
			/* translators: %s: service ID */
			throw new \RuntimeException( esc_html( sprintf( 'Servicio \'%s\' no registrado en el contenedor.', $id ) ) );
		}

		$this->resolved[ $id ] = ( $this->services[ $id ] )();
		return $this->resolved[ $id ];
	}

	/**
	 * Registra los servicios principales del plugin.
	 */
	private function register_services(): void {
		if ( class_exists( 'Woo_OTEC_Moodle_API' ) ) {
			$this->register( 'api', fn() => Woo_OTEC_Moodle_API::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Sync' ) ) {
			$this->register( 'sync', fn() => Woo_OTEC_Moodle_Sync::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Mailer' ) ) {
			$this->register( 'mailer', fn() => Woo_OTEC_Moodle_Mailer::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Logger' ) ) {
			$this->register( 'logger', fn() => Woo_OTEC_Moodle_Logger::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Enroll' ) ) {
			$this->register( 'enroll', fn() => Woo_OTEC_Moodle_Enroll::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Cron' ) ) {
			$this->register( 'cron', fn() => new Woo_OTEC_Moodle_Cron() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_SSO' ) ) {
			$this->register( 'sso', fn() => Woo_OTEC_Moodle_SSO::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Mapper' ) ) {
			$this->register( 'mapper', fn() => Woo_OTEC_Moodle_Mapper::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Admin' ) ) {
			$this->register( 'admin', fn() => Woo_OTEC_Moodle_Admin::instance() );
		}
		if ( class_exists( 'Woo_OTEC_Moodle_Asistente' ) ) {
			$this->register( 'asistente', fn() => Woo_OTEC_Moodle_Asistente::instance() );
		}
	}

	/**
	 * Registra los ganchos principales.
	 */
	private function register_hooks(): void {

		add_action( 'init', array( $this, 'register_runtime' ), 5 );
		add_action( 'before_woocommerce_init', array( $this, 'declare_woocommerce_compatibility' ) );
	}

	/**
	 * Carga el textdomain del plugin.
	 */
	public function load_textdomain(): void {
		load_plugin_textdomain( 'woo-otec-moodle', false, dirname( WOO_OTEC_MOODLE_BASENAME ) . '/languages' );
	}

	/**
	 * Registra el tiempo de ejecución.
	 */
	public function register_runtime(): void {
		$this->load_textdomain();
		$this->register_default_options();

		// ADMIN.
		if ( is_admin() ) {
			if ( class_exists( 'Woo_OTEC_Moodle_Settings' ) ) {
				Woo_OTEC_Moodle_Settings::instance()->register();
			}
			if ( class_exists( 'Woo_OTEC_Moodle_Ajax_Handler' ) ) {
				Woo_OTEC_Moodle_Ajax_Handler::instance()->register();
			}
			if ( class_exists( 'Woo_OTEC_Moodle_Admin' ) ) {
				$this->make( 'admin' )->boot();
			}
			if ( class_exists( 'Woo_OTEC_Moodle_Asistente' ) ) {
				$this->make( 'asistente' )->boot();
			}
		}

		// FRONTEND.
		if ( ! is_admin() ) {
			if ( class_exists( 'Woo_OTEC_Moodle_Frontend' ) ) {
				Woo_OTEC_Moodle_Frontend::instance()->boot();
			}
		}

		if ( class_exists( 'Woo_OTEC_Moodle_Mailer' ) ) {
			$this->make( 'mailer' );
		}

		if ( class_exists( 'Woo_OTEC_Moodle_Enroll' ) ) {
			$this->make( 'enroll' )->boot();
		}

		if ( class_exists( 'Woo_OTEC_Moodle_Cron' ) ) {
			Woo_OTEC_Moodle_Cron::boot();
		}
	}

	/**
	 * Declara la compatibilidad con WooCommerce.
	 */
	public function declare_woocommerce_compatibility(): void {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'custom_order_tables',
				WOO_OTEC_MOODLE_FILE,
				true
			);
		}
	}
}
