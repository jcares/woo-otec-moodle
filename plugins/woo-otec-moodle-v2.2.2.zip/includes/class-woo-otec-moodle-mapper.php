<?php
/**
 * Clase que gestiona el mapeo flexible de campos entre Moodle y WooCommerce.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Woo_OTEC_Moodle_Mapper {

	/** @var Woo_OTEC_Moodle_Mapper|null */
	private static ?Woo_OTEC_Moodle_Mapper $instance = null;

	/**
	 * @return Woo_OTEC_Moodle_Mapper
	 */
	public static function instance(): Woo_OTEC_Moodle_Mapper {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
	}

	/**
	 * @return array
	 */
	public function get_default_mappings(): array {
		return array(
			'fullname'    => array( 'target' => 'post_title', 'label' => 'Nombre del curso', 'enabled' => 'yes' ),
			'summary'     => array( 'target' => 'post_content', 'label' => 'Descripción / Temario', 'enabled' => 'yes' ),
			'startdate'   => array( 'target' => '_start_date', 'label' => 'Fecha de Inicio', 'enabled' => 'yes' ),
			'enddate'     => array( 'target' => '_end_date', 'label' => 'Fecha de Término', 'enabled' => 'yes' ),
			'teacher'     => array( 'target' => '_instructor', 'label' => 'Relator / Docente', 'enabled' => 'yes' ),
			'duration'    => array( 'target' => '_duration', 'label' => 'Duración Cronológica', 'enabled' => 'yes' ),
			'modality'    => array( 'target' => '_modality', 'label' => 'Modalidad de Estudio', 'enabled' => 'yes' ),
			'format'      => array( 'target' => '_course_format', 'label' => 'Estructura del curso', 'enabled' => 'yes' ),
			'sence_code'  => array( 'target' => '_sence_code', 'label' => 'Código SENCE', 'enabled' => 'yes' ),
			'total_hours' => array( 'target' => '_total_hours', 'label' => 'Horas SENCE Totales', 'enabled' => 'yes' ),
		);
	}

	/**
	 * @param array $course_data
	 * @return array
	 */
	public function map_course_data( array $course_data ): array {
		$mappings = $this->get_mappings();
		$mapped   = array();
		foreach ( $mappings as $moodle_key => $config ) {
			if ( isset( $course_data[ $moodle_key ] ) && ( $config['enabled'] ?? 'yes' ) === 'yes' ) {
				$mapped[ $config['target'] ] = $course_data[ $moodle_key ];
			}
		}
		return apply_filters( 'woo_otec_moodle_mapped_course_data', $mapped, $course_data );
	}

	/**
	 * @return array
	 */
	public function get_mappings(): array {
		$saved = Woo_OTEC_Moodle_Core::instance()->get_option( 'mappings', array() );
		return wp_parse_args( (array) $saved, $this->get_default_mappings() );
	}

	/**
	 * @param array $mappings
	 */
	public function save_mappings( array $mappings ): void {
		Woo_OTEC_Moodle_Core::instance()->update_option( 'mappings', $mappings );
	}
}
