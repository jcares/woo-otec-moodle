<?php
/**
 * Gestión del Single Sign-On (SSO) con Moodle.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Woo_OTEC_Moodle_SSO {

	/** @var Woo_OTEC_Moodle_SSO|null */
	private static ?Woo_OTEC_Moodle_SSO $instance = null;

	public static function instance(): Woo_OTEC_Moodle_SSO {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
	}

	public function is_enabled(): bool {
		return 'yes' === Woo_OTEC_Moodle_Core::instance()->get_option( 'sso_enabled', 'yes' );
	}

	public function get_base_url(): string {
		$custom = trim( (string) Woo_OTEC_Moodle_Core::instance()->get_option( 'sso_base_url', '' ) );
		if ( '' !== $custom ) {
			return rtrim( $custom, '/' );
		}
		return Woo_OTEC_Moodle_Core::instance()->make( 'api' )->get_moodle_url();
	}

	public function build_url( string $email, int $course_id = 0 ): string {
		if ( ! $this->is_enabled() ) {
			return '';
		}
		$base_url = $this->get_base_url();
		if ( '' === $base_url ) {
			return '';
		}
		$base_url = rtrim( $base_url, '/' );
		if ( str_ends_with( $base_url, '/login' ) || str_ends_with( $base_url, '/login/index.php' ) ) {
			return esc_url_raw( $base_url );
		}
		return esc_url_raw( $base_url . '/login' );
	}

	/**
	 * Almacena las URLs de acceso en el pedido.
	 *
	 * @param mixed   $order      Pedido (WC_Order).
	 * @param WP_User $user       Usuario.
	 * @param array   $course_ids IDs de los cursos.
	 * @return array
	 */
	public function store_order_urls( $order, WP_User $user, array $course_ids ): array {
		if ( ! $order instanceof WC_Order ) {
			return array();
		}

		$urls = array();
		foreach ( $course_ids as $course_id ) {
			$url = $this->build_url( (string) $user->user_email, (int) $course_id );
			if ( '' !== $url ) {
				$urls[ (int) $course_id ] = $url;
			}
		}
		$order->update_meta_data( '_pcc_moodle_access_urls', $urls );
		$order->update_meta_data( '_moodle_access_url', ! empty( $urls ) ? (string) reset( $urls ) : $this->build_url( (string) $user->user_email ) );
		return $urls;
	}
}
