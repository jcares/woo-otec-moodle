<?php
/**
 * Excepción dedicada para errores de la API de Moodle.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Woo_OTEC_Moodle_Exception extends RuntimeException {

	/** @var string Código de error. */
	private string $error_code;

	/** @var string Función de Moodle. */
	private string $moodle_function;

	/** @var array Contexto adicional. */
	private array $context;

	/**
	 * Constructor.
	 */
	public function __construct( string $message, string $error_code = '', string $moodle_function = '', array $context = array(), int $code = 0, ?\Throwable $previous = null ) {
		parent::__construct( $message, $code, $previous );
		$this->error_code      = $error_code;
		$this->moodle_function = $moodle_function;
		$this->context         = $context;
	}

	/**
	 * @return string
	 */
	public function get_error_code(): string {
		return $this->error_code;
	}

	/**
	 * @return string
	 */
	public function get_moodle_function(): string {
		return $this->moodle_function;
	}

	/**
	 * @return array
	 */
	public function get_context(): array {
		return $this->context;
	}

	/**
	 * @return \WP_Error
	 */
	public function to_wp_error(): \WP_Error {
		return new \WP_Error( $this->error_code ?: 'pcc_moodle_error', $this->getMessage(), $this->context );
	}
}
