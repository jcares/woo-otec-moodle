<?php
/**
 * Orquestador del panel de administración.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Clase que gestiona el panel de administración.
 * Centraliza la configuración, AJAX y renderizado de vistas.
 */
final class Woo_OTEC_Moodle_Admin {

	/** @var Woo_OTEC_Moodle_Admin|null */
	private static ?Woo_OTEC_Moodle_Admin $instance = null;

	/**
	 * Obtiene la instancia única.
	 */
	public static function instance(): Woo_OTEC_Moodle_Admin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
	}

	/**
	 * Inicia la administración.
	 */
	public function boot(): void {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function register_menu(): void {
		add_menu_page(
			'PCC WooOTEC Chile',
			'PCC WooOTEC Chile',
			'manage_options',
			'woo-otec-moodle',
			array( $this, 'render_settings_page' ),
			'dashicons-welcome-learn-more',
			56
		);

		add_submenu_page(
			'woo-otec-moodle',
			'Escritorio',
			'Escritorio',
			'manage_options',
			'woo-otec-moodle',
			array( $this, 'render_settings_page' )
		);

		add_submenu_page(
			'woo-otec-moodle',
			'Asistente',
			'Asistente',
			'manage_options',
			'woo-otec-asistente',
			array( Woo_OTEC_Moodle_Asistente::instance(), 'render_wizard_page' )
		);
	}

	/**
	 * Registra los ajustes del plugin (Settings API).
	 */
	public function register_settings(): void {
		Woo_OTEC_Moodle_Settings::instance()->register();
	}

	/**
	 * Encola assets.
	 */
	public function enqueue_assets( string $hook ): void {
		if ( false === strpos( $hook, 'woo-otec-moodle' ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'woo-otec-modern-ui', WOO_OTEC_MOODLE_URL . 'assets/admin/css/modern-ui.css', array(), WOO_OTEC_MOODLE_VERSION );
		wp_enqueue_script( 'woo-otec-modern-ui', WOO_OTEC_MOODLE_URL . 'assets/admin/js/modern-ui.js', array( 'jquery' ), WOO_OTEC_MOODLE_VERSION, true );
		wp_localize_script( 'woo-otec-modern-ui', 'wooOtecMoodleAdmin', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'woo_otec_moodle_sync_stage' ),
			'emailNonce' => wp_create_nonce( 'woo_otec_moodle_email_tools' ),
			'defaultTab' => $this->get_default_tab(),
			'templateNonce' => wp_create_nonce( 'woo_otec_moodle_template_fields' ),
		) );
	}

	// -------------------------------------------------------------------------
	// Renderizado
	// -------------------------------------------------------------------------

	public function render_settings_page(): void {
		$core          = Woo_OTEC_Moodle_Core::instance();
		$last_sync     = $core->get_option( 'last_sync', array() );
		$connection_ok = $core->make( 'api' )->test_connection();
		$sync_log      = Woo_OTEC_Moodle_Logger::read_tail( Woo_OTEC_Moodle_Logger::SYNC_LOG );
		$error_log     = Woo_OTEC_Moodle_Logger::read_tail( Woo_OTEC_Moodle_Logger::ERROR_LOG );
		$active_tab    = $this->get_default_tab();
		$status        = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';

		include WOO_OTEC_MOODLE_PATH . 'admin/views/settings-page.php';
	}

	public function render_sync_page(): void {
		wp_safe_redirect( add_query_arg( array( 'page' => 'woo-otec-moodle', 'tab' => 'sync' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function render_logs_page(): void {
		wp_safe_redirect( add_query_arg( array( 'page' => 'woo-otec-moodle', 'tab' => 'sync' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Renderiza una vista del administrador.
	 */
	private function render_view( string $file, array $data = array() ): void {
		extract( $data );
		$path = WOO_OTEC_MOODLE_PATH . 'admin/views/' . $file;
		if ( file_exists( $path ) ) {
			include $path;
		}
	}

	private function get_default_tab(): string {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general';
		return in_array( $tab, array( 'general', 'sync', 'sso', 'templates', 'emails', 'logs' ), true ) ? $tab : 'general';
	}

	// -------------------------------------------------------------------------
	// Handlers AJAX / POST
	// -------------------------------------------------------------------------

	public function handle_manual_sync(): void {
		Woo_OTEC_Moodle_Ajax_Handler::instance()->handle_manual_sync();
	}

	public function handle_email_preview(): void {
		Woo_OTEC_Moodle_Ajax_Handler::instance()->handle_email_preview();
	}

	public function handle_send_test_email(): void {
		Woo_OTEC_Moodle_Ajax_Handler::instance()->handle_send_test_email();
	}

	public function handle_template_fields_ajax(): void {
		Woo_OTEC_Moodle_Ajax_Handler::instance()->handle_template_fields_ajax();
	}

	public function handle_get_categories(): void {
		Woo_OTEC_Moodle_Ajax_Handler::instance()->handle_get_categories();
	}

	public function handle_get_teachers(): void {
		Woo_OTEC_Moodle_Ajax_Handler::instance()->handle_get_teachers();
	}

	public function handle_get_courses(): void {
		Woo_OTEC_Moodle_Ajax_Handler::instance()->handle_get_courses();
	}

	public function handle_execute_wizard_sync(): void {
		Woo_OTEC_Moodle_Ajax_Handler::instance()->handle_execute_wizard_sync();
	}

	public function handle_test_sso(): void {
		Woo_OTEC_Moodle_Ajax_Handler::instance()->handle_test_sso();
	}

	public function handle_export_logs(): void {
		Woo_OTEC_Moodle_Ajax_Handler::instance()->handle_export_logs();
	}

	public function handle_generate_zip(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		wp_send_json_success( array( 'url' => '#' ) );
	}

	// -------------------------------------------------------------------------
	// Helpers / Sanitización
	// -------------------------------------------------------------------------

	public function sanitize_array( $v ) { return Woo_OTEC_Moodle_Settings::instance()->sanitize_array( $v ); }
	public function sanitize_checkbox( $v ) { return Woo_OTEC_Moodle_Settings::instance()->sanitize_checkbox( $v ); }
	public function sanitize_email_template( $v ) { return Woo_OTEC_Moodle_Settings::instance()->sanitize_email_template( $v ); }
	public function sanitize_mappings( $v ) { return Woo_OTEC_Moodle_Settings::instance()->sanitize_mappings( $v ); }

	public function get_template_reference_products(): array {
		return function_exists( 'wc_get_products' ) ? wc_get_products( array( 'limit' => 200, 'meta_key' => '_moodle_id', 'meta_compare' => 'EXISTS' ) ) : array();
	}

	public function render_template_fields_markup( int $pid, array $selected, bool $echo = true ): string {
		$meta = get_post_meta( $pid );
		if ( ! is_array( $meta ) ) return '';
		$keys = array_keys( $meta );
		ob_start();
		echo '<div class="pcc-template-fields-grid">';
		foreach ( $keys as $k ) {
			if ( str_starts_with( $k, '_' ) && ! in_array( $k, array( '_instructor', '_start_date', '_end_date', '_duration', '_modality' ) ) ) continue;
			$checked = in_array( $k, $selected, true );
			echo '<label class="pcc-meta-checkbox"><input type="checkbox" name="woo_otec_moodle_template_fields[]" value="' . esc_attr( $k ) . '" ' . checked( $checked, true, false ) . '><span>' . esc_html( $k ) . '</span></label>';
		}
		echo '</div>';
		$html = (string) ob_get_clean();
		if ( $echo ) echo wp_kses_post( $html );
		return $html;
	}
}
