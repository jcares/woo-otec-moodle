<?php
/**
 * Clase que gestiona los ajustes del plugin (Settings API).
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Woo_OTEC_Moodle_Settings {

	/** @var Woo_OTEC_Moodle_Settings|null */
	private static ?Woo_OTEC_Moodle_Settings $instance = null;

	public static function instance(): Woo_OTEC_Moodle_Settings {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
	}

	public function register(): void {
		$fields = array(
			'moodle_url' => 'esc_url_raw', 'moodle_token' => 'sanitize_text_field', 'student_role_id' => 'absint',
			'default_price' => 'sanitize_text_field', 'default_instructor' => 'sanitize_text_field',
			'fallback_description' => 'sanitize_textarea_field', 'default_image_id' => 'absint',
			'sso_base_url' => 'esc_url_raw', 'github_repo' => 'sanitize_text_field', 'github_release_url' => 'esc_url_raw',
			'email_from_address' => 'sanitize_email', 'email_from_name' => 'sanitize_text_field',
			'email_subject' => 'sanitize_text_field', 'email_template' => array( $this, 'sanitize_email_template' ),
			'email_test_recipient' => 'sanitize_email', 'retry_limit' => 'absint',
			'pcc_color_primary' => 'sanitize_hex_color', 'pcc_color_secondary' => 'sanitize_hex_color',
			'pcc_color_text' => 'sanitize_hex_color', 'pcc_color_accent' => 'sanitize_hex_color',
			'template_style' => 'sanitize_text_field', 'template_reference' => 'absint',
		);

		register_setting( 'woo_otec_moodle_settings', 'woo_otec_moodle_template_fields', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_array' ), 'default' => array() ) );
		register_setting( 'woo_otec_moodle_settings', 'woo_otec_moodle_mappings', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_mappings' ), 'default' => array() ) );

		foreach ( $fields as $field => $callback ) {
			register_setting( 'woo_otec_moodle_settings', 'woo_otec_moodle_' . $field, array( 'sanitize_callback' => $callback ) );
		}

		foreach ( array( 'sso_enabled', 'auto_update', 'redirect_after_purchase', 'debug_enabled', 'email_enabled' ) as $field ) {
			register_setting( 'woo_otec_moodle_settings', 'woo_otec_moodle_' . $field, array( 'sanitize_callback' => array( $this, 'sanitize_checkbox' ) ) );
		}
	}

	public function sanitize_array( $v ) { return is_array( $v ) ? array_map( 'sanitize_text_field', $v ) : array(); }
	public function sanitize_checkbox( $v ) { return ( ! empty( $v ) && 'no' !== $v ) ? 'yes' : 'no'; }
	public function sanitize_email_template( $v ) { return wp_kses( (string) $v, Woo_OTEC_Moodle_Core::instance()->make( 'mailer' )->get_email_allowed_html() ); }
	public function sanitize_mappings( $v ) {
		if ( ! is_array( $v ) ) return array();
		$s = array();
		foreach ( $v as $k => $c ) {
			$s[ sanitize_key( $k ) ] = array(
				'target' => sanitize_text_field( $c['target'] ?? '' ),
				'label' => sanitize_text_field( $c['label'] ?? '' ),
				'enabled' => ! empty( $c['enabled'] ) ? 'yes' : 'no',
			);
		}
		return $s;
	}
}
