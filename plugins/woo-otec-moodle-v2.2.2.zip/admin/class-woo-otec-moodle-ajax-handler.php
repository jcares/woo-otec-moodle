<?php
/**
 * Clase que gestiona las peticiones AJAX y envíos de formulario del panel.
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Woo_OTEC_Moodle_Ajax_Handler {

	/** @var Woo_OTEC_Moodle_Ajax_Handler|null */
	private static ?Woo_OTEC_Moodle_Ajax_Handler $instance = null;

	public static function instance(): Woo_OTEC_Moodle_Ajax_Handler {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
	}

	public function register(): void {
		add_action( 'admin_post_woo_otec_moodle_run_sync', array( $this, 'handle_manual_sync' ) );
		add_action( 'wp_ajax_woo_otec_moodle_email_preview', array( $this, 'handle_email_preview' ) );
		add_action( 'wp_ajax_woo_otec_moodle_send_test_email', array( $this, 'handle_send_test_email' ) );
		add_action( 'wp_ajax_woo_otec_moodle_template_fields', array( $this, 'handle_template_fields_ajax' ) );
		add_action( 'wp_ajax_woo_otec_moodle_get_categories', array( $this, 'handle_get_categories' ) );
		add_action( 'wp_ajax_woo_otec_moodle_get_teachers', array( $this, 'handle_get_teachers' ) );
		add_action( 'wp_ajax_woo_otec_moodle_get_courses', array( $this, 'handle_get_courses' ) );
		add_action( 'wp_ajax_woo_otec_moodle_execute_wizard_sync', array( $this, 'handle_execute_wizard_sync' ) );
		add_action( 'wp_ajax_woo_otec_moodle_test_sso', array( $this, 'handle_test_sso' ) );
		add_action( 'wp_ajax_woo_otec_moodle_export_logs', array( $this, 'handle_export_logs' ) );
	}

	public function handle_manual_sync(): void {
		check_admin_referer( 'woo_otec_moodle_run_sync' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No autorizado.' );
		}
		$res = Woo_OTEC_Moodle_Core::instance()->make( 'sync' )->run( true );
		wp_safe_redirect( add_query_arg( array( 'page' => 'woo-otec-moodle', 'tab' => 'sync', 'status' => $res['status'] ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_email_preview(): void {
		check_ajax_referer( 'woo_otec_moodle_email_tools', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		wp_send_json_success( array( 'html' => Woo_OTEC_Moodle_Core::instance()->make( 'enroll' )->render_email_preview() ) );
	}

	public function handle_send_test_email(): void {
		check_ajax_referer( 'woo_otec_moodle_email_tools', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$recipient = sanitize_email( wp_unslash( $_POST['recipient'] ?? '' ) );
		$res = Woo_OTEC_Moodle_Core::instance()->make( 'enroll' )->send_test_email( $recipient );
		is_wp_error( $res ) ? wp_send_json_error( $res->get_error_message() ) : wp_send_json_success( 'Correo enviado.' );
	}

	public function handle_template_fields_ajax(): void {
		check_ajax_referer( 'woo_otec_moodle_template_fields', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$pid = absint( $_POST['product_id'] ?? 0 );
		if ( $pid <= 0 ) {
			wp_send_json_error( 'Producto no válido.' );
		}
		$selected = (array) Woo_OTEC_Moodle_Core::instance()->get_option( 'template_fields', array() );
		wp_send_json_success( array( 'html' => Woo_OTEC_Moodle_Admin::instance()->render_template_fields_markup( $pid, $selected, false ) ) );
	}

	public function handle_get_categories(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$api = Woo_OTEC_Moodle_Core::instance()->make( 'api' );
		$cats = $api->get_categories();
		if ( is_wp_error( $cats ) ) {
			wp_send_json_error( $cats->get_error_message() );
		}
		$options = array();
		foreach ( (array) $cats as $c ) {
			if ( isset( $c->id, $c->name ) ) {
				$options[] = array( 'id' => (int) $c->id, 'name' => (string) $c->name );
			}
		}
		wp_send_json_success( array( 'categories' => $options ) );
	}

	public function handle_get_teachers(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$cat_ids = array_map( 'absint', (array) wp_unslash( $_POST['categories'] ?? array() ) );
		$api = Woo_OTEC_Moodle_Core::instance()->make( 'api' );
		$teachers = array();
		foreach ( $cat_ids as $cid ) {
			$courses = $api->get_courses_by_category( $cid );
			if ( ! is_wp_error( $courses ) ) {
				foreach ( (array) $courses as $course ) {
					$names = $api->get_course_teachers( (int) $course->id );
					foreach ( $names as $n ) {
						$teachers[ $n ] = $n;
					}
				}
			}
		}
		wp_send_json_success( array( 'teachers' => array_values( $teachers ) ) );
	}

	public function handle_get_courses(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$cat_ids = array_map( 'absint', (array) wp_unslash( $_POST['categories'] ?? array() ) );
		$api = Woo_OTEC_Moodle_Core::instance()->make( 'api' );
		$all_courses = array();
		foreach ( $cat_ids as $cid ) {
			$res = $api->get_courses_by_category( $cid );
			if ( ! is_wp_error( $res ) ) {
				foreach ( (array) $res as $c ) {
					if ( (int) $c->id > 1 ) {
						$all_courses[] = $c;
					}
				}
			}
		}
		wp_send_json_success( array( 'courses' => $all_courses ) );
	}

	public function handle_execute_wizard_sync(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$courses = map_deep( wp_unslash( $_POST['courses'] ?? array() ), 'sanitize_text_field' );
		$sync = Woo_OTEC_Moodle_Core::instance()->make( 'sync' );
		$results = array( 'created' => 0, 'updated' => 0, 'errors' => 0 );
		foreach ( $courses as $c ) {
			$res = $sync->sync_single_course( $c );
			if ( 'created' === $res['status'] ) {
				$results['created']++;
			} elseif ( 'updated' === $res['status'] ) {
				$results['updated']++;
			} else {
				$results['errors']++;
			}
		}
		wp_send_json_success( $results );
	}

	public function handle_test_sso(): void {
		check_ajax_referer( 'woo_otec_moodle_wizard', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		$url = esc_url_raw( wp_unslash( $_POST['url'] ?? '' ) );
		$res = wp_remote_get( $url );
		if ( is_wp_error( $res ) ) {
			wp_send_json_error( 'Error: ' . $res->get_error_message() );
		}
		wp_send_json_success( 'Conexión exitosa.' );
	}

	public function handle_export_logs(): void {
		check_admin_referer( 'woo_otec_moodle_export_logs', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No autorizado.' );
		}
		$log = Woo_OTEC_Moodle_Logger::read_full( Woo_OTEC_Moodle_Logger::ERROR_LOG );
		header( 'Content-Type: text/plain' );
		header( 'Content-Disposition: attachment; filename="woo-otec-logs-' . gmdate( 'Y-m-d-His' ) . '.txt"' );
		echo esc_html( $log );
		exit;
	}
}
