<?php
/**
 * Plugin Name:       Woo OTEC Moodle
 * Plugin URI:        https://github.com/jcares/woo-otec-moodle
 * Description:       Integración profesional entre Moodle y WooCommerce. Sincroniza cursos, inscribe alumnos y administra permisos automáticamente.
 * Version:           2.1.0
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            JCares
 * Author URI:        https://www.pccurico.cl
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       woo-otec-moodle
 * Domain Path:       /languages
 * WC requires at least: 8.0
 * WC tested up to:   9.8
 *
 * @package Woo_OTEC_Moodle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Verifica las dependencias críticas antes de cargar el plugin.
 */
function woo_otec_moodle_check_dependencies(): bool {
	// 1. PHP Version check.
	if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
		return false;
	}

	// El check de WooCommerce se movió para permitir que el menú sea visible
	// incluso si WooCommerce no está activo (pero sí avisar).
	return true;
}

/**
 * Muestra un aviso de error si faltan dependencias.
 */
function woo_otec_moodle_admin_notice(): void {
	$message = '';
	if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
		$message = sprintf(
			/* translators: %s: PHP version */
			'Woo OTEC Moodle requiere PHP 8.1 o superior. Tu versión actual es %s.',
			PHP_VERSION
		);
	} elseif ( ! class_exists( 'WooCommerce' ) ) {
		$message = 'Woo OTEC Moodle requiere que WooCommerce esté instalado y activo para funcionar.';
	}

	if ( '' !== $message ) {
		echo '<div class="error"><p>' . esc_html( $message ) . '</p></div>';
	}
}

if ( ! woo_otec_moodle_check_dependencies() ) {
	add_action( 'admin_notices', 'woo_otec_moodle_admin_notice' );
	return;
}

// Mostrar aviso si WooCommerce no está activo.
add_action( 'admin_notices', 'woo_otec_moodle_admin_notice' );

// Constantes base.
define( 'WOO_OTEC_MOODLE_VERSION', '2.1.7' );
define( 'WOO_OTEC_MOODLE_FILE', __FILE__ );
define( 'WOO_OTEC_MOODLE_BASENAME', plugin_basename( __FILE__ ) );
define( 'WOO_OTEC_MOODLE_PATH', plugin_dir_path( __FILE__ ) );
define( 'WOO_OTEC_MOODLE_URL', plugin_dir_url( __FILE__ ) );

// Core.
require_once WOO_OTEC_MOODLE_PATH . 'includes/class-woo-otec-moodle-core.php';

// Hooks de activación.
register_activation_hook( WOO_OTEC_MOODLE_FILE, array( 'Woo_OTEC_Moodle_Core', 'activate' ) );
register_deactivation_hook( WOO_OTEC_MOODLE_FILE, array( 'Woo_OTEC_Moodle_Core', 'deactivate' ) );

// Carga del núcleo del plugin.
Woo_OTEC_Moodle_Core::instance()->boot();
