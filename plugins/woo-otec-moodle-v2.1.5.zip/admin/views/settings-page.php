<?php
/**
 * @var Woo_OTEC_Moodle_Core $core
 * @var array $last_sync
 * @var bool $connection_ok
 * @var array $sync_log
 * @var array $error_log
 * @var string $active_tab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$brand_logo_url        = WOO_OTEC_MOODLE_URL . 'assets/images/logo-pccurico.png';
$last_sync_label       = ! empty( $last_sync['timestamp'] ) ? (string) $last_sync['timestamp'] : 'Sin ejecuciones';
$sync_status           = ! empty( $last_sync['status'] ) ? (string) $last_sync['status'] : 'idle';
$email_from_address    = (string) $core->get_option( 'email_from_address', '' );
$fallback_from_address = Woo_OTEC_Moodle_Core::instance()->make( 'mailer' )->filter_mail_from( get_option( 'admin_email', '' ) );

$current_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'general';

$tabs = array(
	'general'    => 'Conectar Moodle',
	'sync'       => 'Sincronización',
	'sso'        => 'Acceso Alumnos',
	'templates'  => 'Metadatos',
	'appearance' => 'Apariencia',
	'emails'     => 'Emails',
	'logs'       => 'Logs',
);
?>
<div class="wrap">
	<h1>
		<img src="<?php echo esc_url( $brand_logo_url ); ?>" alt="PCCurico" style="height: 30px; vertical-align: middle; margin-right: 10px;">
		PCC WooOTEC Chile PRO
	</h1>

	<nav class="nav-tab-wrapper wp-clearfix" style="margin-bottom: 20px;">
		<?php foreach ( $tabs as $tab_key => $tab_label ) : ?>
			<a href="<?php echo esc_url( add_query_arg( 'tab', $tab_key ) ); ?>" class="nav-tab <?php echo $current_tab === $tab_key ? 'nav-tab-active' : ''; ?>">
				<?php echo esc_html( $tab_label ); ?>
			</a>
		<?php endforeach; ?>
	</nav>

	<div style="margin-bottom: 20px;">
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=woo-otec-asistente' ) ); ?>" class="button button-primary">💫 Iniciar Asistente de Configuración</a>
	</div>

	<form method="post" action="options.php">
		<?php
		settings_fields( 'woo_otec_moodle_settings' );
		?>

		<div class="pcc-tab-content">
			<?php if ( 'general' === $current_tab ) : ?>
				<h2>Conexión Moodle</h2>
				<table class="form-table">
					<tr>
						<th scope="row">URL Moodle</th>
						<td>
							<input class="regular-text" type="url" name="woo_otec_moodle_moodle_url" value="<?php echo esc_attr( (string) $core->get_option( 'moodle_url', '' ) ); ?>">
						</td>
					</tr>
					<tr>
						<th scope="row">Token Moodle</th>
						<td>
							<input class="regular-text" type="password" name="woo_otec_moodle_moodle_token" value="<?php echo esc_attr( (string) $core->get_option( 'moodle_token', '' ) ); ?>" autocomplete="off">
						</td>
					</tr>
					<tr>
						<th scope="row">Role ID estudiante</th>
						<td>
							<input class="small-text" type="number" name="woo_otec_moodle_student_role_id" value="<?php echo esc_attr( (string) $core->get_option( 'student_role_id', 5 ) ); ?>">
						</td>
					</tr>
					<tr>
						<th scope="row">Precio default</th>
						<td>
							<input class="regular-text" type="text" name="woo_otec_moodle_default_price" value="<?php echo esc_attr( (string) $core->get_option( 'default_price', '49000' ) ); ?>">
						</td>
					</tr>
				</table>
			<?php endif; ?>

			<?php if ( 'sync' === $current_tab ) : ?>
				<h2>Sincronización</h2>
				<div class="card" style="max-width: 100%; margin-top: 0;">
					<p><strong>Última ejecución:</strong> <?php echo esc_html( $last_sync_label ); ?> (<?php echo esc_html( $sync_status ); ?>)</p>
					<p>Para realizar una sincronización completa, utiliza el botón de abajo o el asistente.</p>
				</div>
				<p class="submit">
					<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=woo_otec_moodle_run_sync' ), 'woo_otec_moodle_run_sync' ) ); ?>" class="button button-secondary">Ejecutar sincronización manual ahora</a>
				</p>
			<?php endif; ?>

			<?php if ( 'sso' === $current_tab ) : ?>
				<h2>Acceso Alumnos (SSO)</h2>
				<table class="form-table">
					<tr>
						<th scope="row">Activar SSO</th>
						<td>
							<input type="checkbox" name="woo_otec_moodle_sso_enabled" value="yes" <?php checked( $core->get_option( 'sso_enabled', 'yes' ), 'yes' ); ?>>
						</td>
					</tr>
					<tr>
						<th scope="row">URL base SSO</th>
						<td>
							<input class="regular-text" type="url" name="woo_otec_moodle_sso_base_url" value="<?php echo esc_attr( (string) $core->get_option( 'sso_base_url', '' ) ); ?>">
						</td>
					</tr>
				</table>
			<?php endif; ?>

			<?php if ( 'templates' === $current_tab ) : ?>
				<h2>Metadatos</h2>
				<table class="form-table">
					<tr>
						<th scope="row">Estilo de Plantilla</th>
						<td>
							<select name="woo_otec_moodle_template_style">
								<?php $current_style = $core->get_option( 'template_style', 'classic' ); ?>
								<option value="classic" <?php selected( $current_style, 'classic' ); ?>>Classic (WooCommerce Default)</option>
								<option value="academy" <?php selected( $current_style, 'academy' ); ?>>Academy (Moderna/LMS)</option>
								<option value="pccurico" <?php selected( $current_style, 'pccurico' ); ?>>PCCurico</option>
							</select>
						</td>
					</tr>
				</table>
			<?php endif; ?>

			<?php if ( 'appearance' === $current_tab ) : ?>
				<h2>Apariencia</h2>
				<table class="form-table">
					<tr>
						<th scope="row">Color Primario</th>
						<td>
							<input type="color" name="woo_otec_moodle_pcc_color_primary" value="<?php echo esc_attr( (string) $core->get_option( 'pcc_color_primary', '#023E25' ) ); ?>">
						</td>
					</tr>
					<tr>
						<th scope="row">Color Secundario</th>
						<td>
							<input type="color" name="woo_otec_moodle_pcc_color_secondary" value="<?php echo esc_attr( (string) $core->get_option( 'pcc_color_secondary', '#6EC1E4' ) ); ?>">
						</td>
					</tr>
				</table>
			<?php endif; ?>

			<?php if ( 'emails' === $current_tab ) : ?>
				<h2>Configurar Emails</h2>
				<table class="form-table">
					<tr>
						<th scope="row">Activar envío</th>
						<td>
							<input type="checkbox" name="woo_otec_moodle_email_enabled" value="yes" <?php checked( $core->get_option( 'email_enabled', 'yes' ), 'yes' ); ?>>
						</td>
					</tr>
					<tr>
						<th scope="row">Email remitente</th>
						<td>
							<input class="regular-text" type="email" name="woo_otec_moodle_email_from_address" value="<?php echo esc_attr( $email_from_address ); ?>" placeholder="<?php echo esc_attr( $fallback_from_address ); ?>">
						</td>
					</tr>
					<tr>
						<th scope="row">Asunto</th>
						<td>
							<input class="regular-text" type="text" name="woo_otec_moodle_email_subject" value="<?php echo esc_attr( (string) $core->get_option( 'email_subject', '' ) ); ?>">
						</td>
					</tr>
					<tr>
						<th scope="row">Plantilla HTML</th>
						<td>
							<textarea class="large-text code" rows="10" name="woo_otec_moodle_email_template"><?php echo esc_textarea( (string) $core->get_option( 'email_template', '' ) ); ?></textarea>
						</td>
					</tr>
				</table>
			<?php endif; ?>

			<?php if ( 'logs' === $current_tab ) : ?>
				<h2>Registro de errores</h2>
				<div style="background: #1e1e1e; color: #d4d4d4; padding: 15px; border-radius: 4px; font-family: monospace; font-size: 12px; max-height: 400px; overflow-y: auto; margin-bottom: 20px;">
					<?php
					if ( ! empty( $error_log ) ) {
						foreach ( $error_log as $line ) {
							echo esc_html( $line ) . '<br>';
						}
					} else {
						echo 'No hay registros recientes.';
					}
					?>
				</div>
				<p>
					<a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=woo_otec_moodle_export_logs&nonce=' . wp_create_nonce( 'woo_otec_moodle_export_logs' ) ) ); ?>" class="button">Exportar log completo</a>
				</p>
			<?php endif; ?>
		</div>

		<?php if ( 'logs' !== $current_tab && 'sync' !== $current_tab ) : ?>
			<?php submit_button( 'Guardar configuración' ); ?>
		<?php endif; ?>
	</form>
</div>
